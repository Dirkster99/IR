﻿namespace UnitComboLib.Unit.Temperature
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  public class TemperaturDegreeFahrenheit
  {
    private double mValue = 0;

    #region constructor
    public TemperaturDegreeFahrenheit(double value)
    {
      this.mValue = value;
    }

    private TemperaturDegreeFahrenheit()
    {      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      TemperaturDegreeFahrenheit d = new TemperaturDegreeFahrenheit(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.TemperaturCelsius:
          return (this.mValue - 32 ) * 5/9;

        case Itemkey.TemperaturDegreeFahrenheit:
          return this.mValue;

        case Itemkey.TemperaturKelvin:
          return (this.mValue + 459.67) * 5/9;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

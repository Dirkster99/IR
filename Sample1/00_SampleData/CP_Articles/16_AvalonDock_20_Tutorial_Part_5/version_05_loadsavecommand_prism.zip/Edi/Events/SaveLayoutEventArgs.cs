namespace Edi.Events
{
  /// <summary>
  /// Class implements ...
  /// </summary>
  class SaveLayoutEventArgs
  {
    public string XmlLayout { get; set; }
  }
}

﻿namespace HTMLTitleParser.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Linq;

  using HtmlAgilityPack;
  using Progress;

  public class ProcessHTMLVM : ProgressVM
  {
    #region fields
    /// <summary>
    /// Key for parameter dictionary string object: HTMLDirectoryPath
    /// </summary>
    public static readonly string KeyDirPath = "HTMLDirectoryPath";

    /// <summary>
    /// Key for result dictionary object of: files (and their title) collection
    /// </summary>
    public static readonly string KeyMapFileToTitle = "MapFileToTitle";
    #endregion fields

    #region Constructor
    public ProcessHTMLVM() : base()
    {
    }
    #endregion Constructor

    #region Properties
    /// <summary>
    /// Get the name of the process (being executed) so that it may be used in the GUI.
    /// </summary>
    public override string ProcessName
    {
      get
      {
        return "Process HTML";
      }
    }
    #endregion Properties

    #region Methods
    /// <summary>
    /// Process HTML files and extract all titles from each file stored there
    /// </summary>
    /// <param name="callParameters"></param>
    /// <returns></returns>
    public int ProcessHTMLDirectory(Dictionary<string, object> callParameters)
    {
      if (callParameters == null)
      {
        this.AddMessage(string.Format("Internal Error callParameters does not exist."));
        this.AbortedWithErrors = true;
        return ProgressVM.Failed;
      }

      string sDir = null;
      object o;
      if (callParameters.TryGetValue(ProcessHTMLVM.KeyDirPath, out o) == true)
        sDir = o as string;

      if (sDir == null)
      {
        this.AddMessage(string.Format("Internal Error callParameters {0} does not exist.", ProcessHTMLVM.KeyDirPath));
        this.AbortedWithErrors = true;
        return ProgressVM.Failed;
      }

      string[] files = System.IO.Directory.GetFiles(sDir, "*.htm", System.IO.SearchOption.TopDirectoryOnly);

      if (files == null) return ProgressVM.OkNoError;

      this.ProgressMax = files.Length;
      this.ProgressMin = this.ProgressValue = 0;

      Dictionary<string, string> mapFileToTitle = new Dictionary<string, string>();

      foreach (string sFile in files)
      {
        // Check if cancel is requested and exit if that is so...
        if (this.CancelTokenSource.Token.IsCancellationRequested == true)
        {
          this.AbortedWithCancel = true;
          return ProgressVM.Cancelled;
        }

        string sFileName = System.IO.Path.GetFileNameWithoutExtension(sFile);
        this.StatusMessage = string.Format("Processing: {0}", sFileName);

        string sTitle = sFileName;

        if (sTitle.Length > 30)
          sTitle = sTitle.Substring(0, 29);

        try
        {
          // Process HTML files
          HtmlDocument html = new HtmlDocument();
          html.LoadHtml(System.IO.File.ReadAllText(sFile));

          if (html.DocumentNode.HasChildNodes == true)
          {
            // Parse document and attempt to find TITLE tag via XPath query
            IEnumerable<HtmlNode> nodes = Enumerable.Empty<HtmlNode>();

            nodes = html.DocumentNode.SelectNodes("html/head/title");

            // Take a note of the parsed title and add it to collecitons in finally block
            if (nodes.Count() == 1)
              sTitle = nodes.ElementAt(0).InnerHtml.Trim();
          }
        }
        catch
        {
        }
        finally
        {
          mapFileToTitle.Add(sFile, sTitle);
          this.AddMessage(string.Format("{0} Finished processing: '{1}'", TStamp, sTitle));
        }

        this.ProgressValue += 1;
      }

      this.callResults.Add(ProcessHTMLVM.KeyMapFileToTitle, mapFileToTitle);

      return ProgressVM.OkNoError;
    }
    #endregion Methods
  }
}

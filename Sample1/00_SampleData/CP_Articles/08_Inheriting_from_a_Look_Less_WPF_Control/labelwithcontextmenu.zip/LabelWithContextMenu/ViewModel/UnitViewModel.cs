﻿namespace LabelWithContextMenu.ViewModel
{
  using System.Collections.ObjectModel;
  using System.Linq;
  using System.Windows.Input;

  using LabelWithContextMenu.Command;
  using LabelWithContextMenu.Unit;

  public class UnitViewModel : BaseViewModel
  {
    #region fields
    private ListItem mSelectedItem = null;

    private ObservableCollection<ListItem> mUnitList = null;

    private double mValue = 0;

    private Converter mUnitConverter = null;
    #endregion fields

    #region constructor
    protected UnitViewModel()
    {
    }

    public UnitViewModel(ObservableCollection<ListItem> list,
                         Converter unitConverter,
                         int DefaultIndex=0,
                         double defaultValue = 100)
    {
      this.mUnitList = new ObservableCollection<ListItem>(list);
      this.mSelectedItem = this.mUnitList[DefaultIndex];

      this.mUnitConverter = unitConverter;
      this.mValue = defaultValue;
    }
    #endregion constructor

    #region properties
    public ObservableCollection<ListItem> UnitList
    {
      get
      {
        return this.mUnitList;
      }
    }

    public ListItem SelectedItem
    {
      get
      {
        return this.mSelectedItem;
      }

      set
      {
        if (this.mSelectedItem != value)
        {
          this.mSelectedItem = value;
          this.NotifyPropertyChanged(() => this.SelectedItem);
        }
      }
    }

    /// <summary>
    /// Get double value represented in unit as indicated by SelectedItem.Key.
    /// </summary>
    public double Value
    {
      get
      {
        return this.mValue;
      }

      set
      {
        if (this.mValue != value)
        {
          this.mValue = value;
          this.NotifyPropertyChanged(() => this.Value);
        }
      }
    }

    private RelayCommand<Itemkey> mSetSelectedItemCommand = null;
    public ICommand SetSelectedItemCommand
    {
      get
      {
        if (this.mSetSelectedItemCommand == null)
          this.mSetSelectedItemCommand = new RelayCommand<Itemkey>(p => this.SetSelectedItemExecuted(p), p => true);

        return this.mSetSelectedItemCommand;
      }
    }
    #endregion properties

    #region methods
    /// <summary>
    /// Convert current double value from current unit to
    /// unit as indicated by <paramref name="unitKey"/> and
    /// set corresponding SelectedItem.
    /// </summary>
    /// <param name="unitKey">New unit to convert double value into and set SelectedItem to.</param>
    /// <returns></returns>
    private object SetSelectedItemExecuted(Itemkey unitKey)
    {
      // Attempt to find the next selected item
      ListItem li = this.mUnitList.SingleOrDefault(i => i.Key == unitKey);

      // Convert from current item to find the next selected item
      if (li != null)
      {
        this.Value = this.mUnitConverter.Convert(this.SelectedItem.Key, this.mValue, li.Key);

        this.SelectedItem = li;
      }

      return null;
    }
    #endregion methods
  }
}

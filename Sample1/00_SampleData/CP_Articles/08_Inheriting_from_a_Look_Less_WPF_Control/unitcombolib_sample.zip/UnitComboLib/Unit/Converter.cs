﻿namespace UnitComboLib.Unit
{
  /*** http://de.wikipedia.org/wiki/Grad_Fahrenheit

  Kelvin
       Celsius = Kelvin-273.15
        Kelvin = Kelvin
    Fahrenheit = Kelvin * 1,8 − 459,67
  ------------------------
  Fahrenheit
         Celsius = (Fahrenheit - 32 ) × 5 / 9
          Kelvin = (Fahrenheit + 459,67) * 5⁄9
      Fahrenheit = Fahrenheit
  
  ------------------------
  Celsius
       Celsius = Celsius
        Kelvin = Celsius+273.15
    Fahrenheit = (( Celsius × 9 ) / 5 ) + 32
  ***/

  /// <summary>
  /// Enumeration keys for each unit
  /// </summary>
  public enum Itemkey
  {
    TemperaturCelsius = 7,
    TemperaturKelvin = 8,
    TemperaturDegreeFahrenheit = 9
  }

  public abstract class Converter
  {
    public abstract double Convert(Itemkey inputUnit, double inputValue, Itemkey outputUnit);
  }
}

﻿namespace SimpleControls.WatermarkTextBox
{
  using System.Windows;
  using System.Windows.Controls;

  /// <summary>
  /// Interaction logic for TextBoxWithWaterMark.xaml
  /// 
  /// Source: http://www.dotnetspark.com/kb/1716-create-watermark-textbox-wpf-application.aspx
  /// </summary>
  public partial class TextBoxWithWatermark : UserControl
  {
    #region fields
    private static readonly DependencyProperty LabelTextBoxProperty =
      DependencyProperty.Register("LabelTextBox", typeof(string), typeof(TextBoxWithWatermark));

    private static readonly DependencyProperty TextProperty =
      TextBox.TextProperty.AddOwner(typeof(TextBoxWithWatermark));

    private static readonly DependencyProperty WatermarkProperty =
      DependencyProperty.Register("Watermark", typeof(string), typeof(TextBoxWithWatermark));
    #endregion fields

    #region constructor
    public TextBoxWithWatermark()
    {
      this.InitializeComponent();
    }
    #endregion constructor

    #region properties
    /// <summary>
    /// Declare a TextBox label dependency property
    /// </summary>
    public string LabelTextBox
    {
      // These proeprties can be bound to. The XAML for this control binds the Label's content to this.
      get { return (string)GetValue(TextBoxWithWatermark.LabelTextBoxProperty); }
      set { SetValue(TextBoxWithWatermark.LabelTextBoxProperty, value); }
    }

    /// <summary>
    /// Declare a TextBox Text dependency property
    /// </summary>
    public string Text
    {
      // These proeprties can be bound to. The XAML for this control binds the Label's content to this.
      get { return (string)GetValue(TextBoxWithWatermark.TextProperty); }
      set { SetValue(TextBoxWithWatermark.TextProperty, value); }
    }

    /// <summary>
    /// Declare a TextBox Watermark label dependency property
    /// </summary>
    public string Watermark
    {
      // These proeprties can be bound to. The XAML for this control binds the Watermark's content to this.
      get { return (string)GetValue(TextBoxWithWatermark.WatermarkProperty); }
      set { SetValue(TextBoxWithWatermark.WatermarkProperty, value); }
    }
    #endregion properties
  }
}

﻿namespace FileSize_Converter_Test
{
  using System;
  using System.Windows;

  /// <summary>
  /// Interaction logic for TestWindow1.xaml
  /// </summary>
  public partial class TestDialog : Window
  {
    public TestDialog()
    {
      this.InitializeComponent();

      this.bCancel = true;
    }

    #region Properties
    /// <summary>
    /// Determine Title of product
    /// </summary>
    public bool bCancel
    {
      get;

      set;
    }
    #endregion Properties

    #region Methods
    /// <summary>
    /// Cancel button has been clicked
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void bthnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.bCancel = true;
      this.Close();
    }


    /// <summary>
    /// OK button has been clicked
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnOK_Click(object sender, RoutedEventArgs e)
    {
      this.bCancel = false;
      this.Close();
    }

    /// <summary>
    /// Set minimum/maximum of allowed numberpf byte values entered in the dialog
    /// </summary>
    /// <param name="Min"></param>
    /// <param name="Max"></param>
    public void SetMinMax(ulong Min, ulong Max)
    {
      ulong[] MinMax = this.FindResource("MockupMinMaxValues") as ulong[];

      if(MinMax != null)
      {
        MinMax[0] = Min;
        MinMax[1] = Max;
      }
    }
    #endregion Methods
  }
}

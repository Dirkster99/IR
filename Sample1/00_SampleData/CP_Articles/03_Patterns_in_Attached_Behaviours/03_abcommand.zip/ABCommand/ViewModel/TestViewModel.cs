﻿namespace ABCommand.ViewModel
{
  using System.Windows;

  class TestViewModel : ViewModelBase
  {
    public TestViewModel()
    {
    }

    public void LoadFile(string FilePath)
    {
      MessageBox.Show(string.Format("Opening file '{0}'", FilePath), "Debug Info", MessageBoxButton.OK);
    }
  }
}

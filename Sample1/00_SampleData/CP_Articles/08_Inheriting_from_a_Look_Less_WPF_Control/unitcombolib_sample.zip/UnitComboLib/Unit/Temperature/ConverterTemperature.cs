﻿namespace UnitComboLib.Unit.Temperature
{
  using System;
  
  public class ConverterTemperature : Converter
  {
    public const double DefaultTemperatureCelsius = 100.0;

    public const double DefaultTemperatureFahrenheit = 212.0;

    public const double DefaultTemperatureKelvin = 373.15;

    /// <summary>
    /// Convert between different units of screen resolutions.
    /// </summary>
    /// <param name="inputUnit"></param>
    /// <param name="inputValue"></param>
    /// <param name="outputUnit"></param>
    /// <returns></returns>
    public override double Convert(Itemkey inputUnit, double inputValue, Itemkey outputUnit)
    {
      switch (inputUnit)
      {
        case Itemkey.TemperaturCelsius:
          return TemperaturCelsius.ToUnit(inputValue, outputUnit);

        case Itemkey.TemperaturDegreeFahrenheit:
          return TemperaturDegreeFahrenheit.ToUnit(inputValue, outputUnit);

        case Itemkey.TemperaturKelvin:
          return TemperaturKelvin.ToUnit(inputValue, outputUnit);

        default:
          throw new NotImplementedException(outputUnit.ToString());
       }
    }
  }
}

Open Icon Library Standard Package

---------------

License descriptions


Many of our packages use icons from many different sources. And these sources are under various different free/open licenses. Given this, Our package licenses get a little messy. But don't worry. All are icons are free and open, and each icons license is well documented

Icon Usage Rights

    Free to use for commercial or non-commercial, roalty-free
    Free to modify
    Free to redistribute


Icon Usage Restriction

    Must retain origonal icons license
    Must retain origonal icons authors
    for more details see the individual licenses

Restrictions do not apply to Public Domain icons

How to find the license of an icon

Find license from the license file

    Search for the file name in the license file

Find license from the icons metadata

    PNG: Execute 'identify -verbose file_name.png'
    SVG: Open the image in a text editor. Or. Open file with Inkscape; click 'file'; 'Document Metadata'.
    XPM: Open the image in a text editor.
    ICO: We currently don't know how to embed comments in these files. (Know how?)
    ICNS: We currently don't know how to embed comments in these files.(Know how?)

---------------

Package from
https://sourceforge.net/projects/openiconlibrary/files/0.11/open_icon_library-standard-0.11.zip/download

Used SharpVectors from http://sharpvectors.codeplex.com/
for initial conversion to XAML

Used Notepad++ to find - Replace (normal string search without single quotes):


'<DrawingGroup xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">'
'<Canvas xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"><Canvas.Background>  <DrawingBrush><DrawingBrush.Drawing><DrawingGroup>'


Used Notepad++ to find - Replace (Regular expression string search without single quotes):

'^</DrawingGroup>'
'      </DrawingGroup></DrawingBrush.Drawing></DrawingBrush></Canvas.Background></Canvas>'
﻿namespace HTMLTitleParser.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Input;

  using Progress;

  public partial class AppVM : BaseVM
  {
    #region Properties
    /// <summary>
    /// Processing ViewModel exposing properties for multiple
    /// progressbars visibility and start/stop GUI enablements.
    /// </summary>  
    public MultiProgressVM MultiProgress
    {
      get
      {
        return this.mMultiProgress;
      }

      private set
      {
        this.mMultiProgress = value;
        this.OnPropertyChanged(Bind.PropName(() => this.MultiProgress));
      }
    }
    #endregion Properties

    #region Methods
    /// <summary>
    /// Determine whether a command can be executed based on the fact
    /// if there is a background process in progress or not.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public void CanExecute_IfNoMultiProcessRuns(object sender, CanExecuteRoutedEventArgs e)
    {
      e.Handled = true;

      if (e != null && this.MultiProgress != null)
      {
        string sProcessName;     // Allow only if there is no other process running
        e.CanExecute = !this.MultiProcessIsRunning(out sProcessName);
        return;
      }

      e.CanExecute = false;
    }

    /// <summary>
    /// Main entry point of simple HTML processing in the
    /// Applictaion ViewModel. This method does all the housekeeping
    /// to bind GUI controls to their respective properties. Start the
    /// backgound processing and registers another result method
    /// <see cref="AppVM.ProcessHTML_Results"/> to be executed
    /// when the background processing is finished (with or without errors).
    /// </summary>
    /// <param name="e"></param>
    /// <param name="progressBar"></param>
    /// <param name="statusTextBox"></param>
    /// <param name="lstResults"></param>
    /// <param name="btnStop"></param>
    /// <returns></returns>
    public bool MultiProcessHTMLDirectory(ExecutedRoutedEventArgs e,
                                           ProgressBar progressBar,
                                           TextBox statusTextBox,
                                           ListView statusListView,
                                           ListView lstResults,
                                           Button btnStop)
    {
      e.Handled = true;
      string dirPath = (string)e.Parameter;

      if (this.MultiProgress != null)
      {     // Emergency stop: Don't run twice...
        if (this.MultiProgress.CanCancelRunProcess == true)
          return false;
      }

      try
      {
        // Check if process is currently running or not
        string sProcessName;
        if (this.MultiProcessIsRunning(out sProcessName) == true)
        {
          MessageBox.Show("A " + sProcessName + " is currently being executed. Only one process can be executed at a time.", "Process is being executed",
                            MessageBoxButton.OK, MessageBoxImage.Information);
          return false;
        }

        this.MultiBindStatusBarItems(TypeOfProcess.MultiProcessHTML,
                                      progressBar, statusTextBox, statusListView,
                                      lstResults, btnStop, this.MultiProcessHTML_Results);

        this.MultiProgress.SetProgressMessage(true);

        // Force refresh of CanExecute Command framework functions ...
        CommandManager.InvalidateRequerySuggested();

        Dictionary<string, object> callParams = new Dictionary<string, object>();
        callParams.Add(ViewModel.MultiProcessHTMLVM.KeyDirPath, dirPath);

        // Set parameters (if any) and method to run and run it asynchronously
        this.MultiProgress.RunProcess(true, callParams,
                                      ((MultiProcessHTMLVM)this.MultiProgress).ProcessHTMLDirectory);
      }
      catch (Exception exc)
      {
        MessageBox.Show(exc.ToString());
      }

      return true;
    }

    /// <summary>
    /// Cancel processing of the currently running process
    /// </summary>
    /// <param name="e"></param>
    public void CancelMultiProcessing(ExecutedRoutedEventArgs e)
    {
      e.Handled = true;

      if (this.mMultiProgress != null)
        this.mMultiProgress.Cancel();
    }

    /// <summary>
    /// Determine whether a process is currently running or not and return its name (if any)
    /// </summary>
    /// <returns></returns>
    internal bool MultiProcessIsRunning(out string processName)
    {
      processName = string.Empty;

      if (this.MultiProgress != null)
      {
        if (this.MultiProgress.CanCancelRunProcess == true)
        {
          processName = this.MultiProgress.ProcessName;
          return true;
        }
      }

      return false;
    }

    /// <summary>
    /// This function is called when the <seealso cref="ProcessHTMLDirectory.ProcessHTMLDirectory"/>
    /// completes. The <paramref name="e"/> parameter is used to display the result in the GUI.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void MultiProcessHTML_Results(object sender, MultiProcessHTMLVM.ProgressResult e)
    {
      // Force refresh of CanExecute Command framework functions ...
      CommandManager.InvalidateRequerySuggested();

      if (e.Cancel == true || e.Error == true)
      {
        if (e.Cancel == true)
          this.MultiProgress.StatusMessage = string.Format("Cancelled by user with result code {0}", e.ResultCode);
        else
        {
          if (e.InnerException != null)
            this.MultiProgress.StatusMessage = string.Format("{0}, result code:{1}", e.InnerException.Message, e.ResultCode);
          else
            this.MultiProgress.StatusMessage = string.Format("Process finished with errors and result code {0}", e.ResultCode);
        }

        return;
      }

      // Set processing result in application viewmodel and make it visible in GUI
      object o;
      if (e.ResultObjects.TryGetValue(ProcessHTMLVM.KeyMapFileToTitle, out o) == true)
        this.MapFile2Title = o as Dictionary<string, string>;

      // Reset status message to indicate that the system is wating for input
      this.MultiProgress.StatusMessage = ProgressVM.StrReady;
    }

    /// <summary>
    /// Reset GUI bindings of progress elements and construct a new processing class
    /// (eg.: for Backup/Restore operation)
    /// </summary>
    /// <param name="progressBar"></param>
    /// <param name="statusTextBox"></param>
    /// <param name="lstResults"></param>
    /// <param name="btnStop"></param>
    /// <param name="btnExec"></param>
    private void MultiBindStatusBarItems(TypeOfProcess typeOfProcess,
                                         ProgressBar progressBar,
                                         TextBox statusTextBox,
                                         ListView statusListView,
                                         ListView lstResults,
                                         Button btnStop,
                                         EventHandler<MultiProgressVM.ProgressResult> processCompleted = null)
    {
      MultiProgressVM retProcess = null;

      switch (typeOfProcess)
      {
        case TypeOfProcess.MultiProcessHTML:
          retProcess = new MultiProcessHTMLVM(2);
          break;

        default:
          throw new NotImplementedException(
                string.Format("The process type: {0} is not supported.", typeOfProcess));
      }

      // Get an initially collapsed progress bar plus binding
      MultiProgressVM tExec = MultiProgressVM.BindProgressStatusItems(
                                retProcess, null,  ////progressBar,
                                statusTextBox,
                                statusListView,
                                lstResults,
                                btnStop);

      tExec.CanRunProcess = false;
      tExec.CanCancelRunProcess = true;

      if (processCompleted != null)
        tExec.resultEvent += processCompleted;

      this.MultiProgress = tExec;
    }
    #endregion Methods
  }
}

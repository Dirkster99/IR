﻿namespace BringListViewItemIntoView
{
  using System.Windows;
  using System.Windows.Input;
  using ViewModel;
  using View;

  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
    private void Application_Startup(object sender, StartupEventArgs e)
    {
      // Construct ViewModel and MainWindow
      TestViewModel tVM = new TestViewModel();
      MainWindow win = new MainWindow();

      // Attach ViewModel to DataContext of ViewModel
      win.DataContext = tVM;

      this.InitMainWindowCommandBinding(win);

      // SHOW ME DA WINDOW!
      win.Show();
    }

    /// <summary>
    /// Initialize the RoutedCommand binding between MainWindow View and ViewModel
    /// </summary>
    /// <param name="win"></param>
    public void InitMainWindowCommandBinding(Window win)
    {
      win.CommandBindings.Add(new CommandBinding(AppCommand.Processing,
      (s, e) =>
      {
        ((TestViewModel)win.DataContext).Processing();

        e.Handled = true;
      }));
    }
  }
}

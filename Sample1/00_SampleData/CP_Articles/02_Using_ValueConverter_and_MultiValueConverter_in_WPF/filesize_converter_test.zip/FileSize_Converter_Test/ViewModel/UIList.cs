﻿namespace FileSize_Converter_Test.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  using FSControls.FileSize;

  /// <summary>
  /// This is just a simple helper class to support UI, such as,
  /// ListBoxes and ListItems when working with ENUMS
  /// </summary>
  public sealed class UIList
  {
    public UIList(object key,
                  string value,
                  string desription = "")
    {
      this.Key = key;
      this.Value = value;
      this.Description = desription;
    }

    #region Properties
    /// <summary>
    /// This is a value representation
    /// </summary>
    public string Value { get; set; }

    /// <summary>
    /// This is a key representation
    /// </summary>
    public object Key { get; set; }

    /// <summary>
    /// This is a human read-ably description (may be used as tool tip)
    /// </summary>
    public string Description { get; set; }
    #endregion Properties

    #region Methods
    /// <summary>
    /// Load all Types of supported memory units and use the resulting
    /// list structure in Options GUI (listbox, combobox etc...)
    /// </summary>
    /// <returns></returns>
    public static Dictionary<MemUnit, UIList> GetDicOfCompressionLevels()
    {
      Dictionary<MemUnit, UIList> table = new Dictionary<MemUnit, UIList>();

      foreach (MemUnit memUnit in Enum.GetValues(typeof(MemUnit)))
      {
        UIList item = new UIList(memUnit, memUnit.ToString(), string.Empty);

        table.Add(memUnit, item);
      }

      return table;
    }

    public override string ToString()
    {
      string sRet = string.Empty;

      sRet += "Key: '" + (this.Key == null ? "(null)" : this.Key) + "'";
      sRet += ",Value: '" + (this.Value == null ? "(null)" : this.Value) + "'";
      sRet += ",Description: '" + (this.Description == null ? "(null)" : this.Description) + "'";

      return sRet;
    }
    #endregion Methods
  }
}

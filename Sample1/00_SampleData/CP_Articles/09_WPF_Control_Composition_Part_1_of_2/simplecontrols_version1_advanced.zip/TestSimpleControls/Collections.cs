﻿namespace TestSimpleControls
{
  using System;
  using System.Collections;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  /// <summary>
/// Stellt für den ObjectProvider im XAML die ComboBoxItems zur Verfuegung
/// </summary>
  public static class Collections
  {
    public enum Anrede
    {
      UnknownTitle = 0,
      Mr = 1,
      Mrs = 2,
      Ms = 3,
      MrAndMrs = 4,
      Company = 5
    }

    /// <summary>
    /// Load combo box content via Object DataProvider based on static method as DataSource
    /// (see XAML of window for mor details).
    /// 
    /// Source: http://www.biggle.de/blog/combobox-an-objectprovider-binden
    /// </summary>
    /// <returns></returns>
    public static Dictionary<Anrede, string> GetFormOfAddress()
    {
      Dictionary<Anrede, string> choices = new Dictionary<Anrede, string>();
      choices.Add(Anrede.UnknownTitle, "Without Title");
      choices.Add(Anrede.Mr, "Mr");
      choices.Add(Anrede.Mrs, "Mrs");
      choices.Add(Anrede.Ms, "Ms");
      choices.Add(Anrede.MrAndMrs, "Mr and Mrs");
      choices.Add(Anrede.Company, "Company");

      return choices;
    }
  }
}

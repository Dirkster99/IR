﻿namespace HTMLTitleParser.View
{
  using System.Windows;
  using System.Windows.Input;

  using ViewModel;

  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MultiProgressWindow : Window
  {
    #region Constructor
    public MultiProgressWindow()
    {
      this.InitializeComponent();

      // Construct an ApplicationViewModel
      // initialize it from persistence
      // and attach it to the DataContext via AppVM property
      ViewModel.AppVM appVM = new ViewModel.AppVM();
      
      if (Properties.Settings.Default.InputDirectory != null)
        appVM.Path = Properties.Settings.Default.InputDirectory;

      this.AppVM = appVM;

      this.BindCommands();
    }
    #endregion Constructor

    #region Properties
    /// <summary>
    /// Wrap an ApplicationViewModel property around the DataContext of this
    /// (we do not use DataContext anywhere else directly because debugging
    /// is a nighmare otherwise ...)
    /// </summary>
    public AppVM AppVM
    {
      get
      {
        return this.DataContext as AppVM;
      }

      set
      {
        this.DataContext = value;
      }
    }
    #endregion Properties

    #region Methods
    /// <summary>
    /// Save current user settings on applciation shut down
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnWindowClosing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      Properties.Settings.Default.InputDirectory = ((AppVM)this.DataContext).Path;
      Properties.Settings.Default.Save();
    }

    /// <summary>
    /// Bind commands and background methods at run-time
    /// </summary>
    private void BindCommands()
    {
      // Bind ProcessHTML command to Application ViewModel method to execute when command executes
      // Progress properties are bound to the listed controls (dynamically at command runtime)
      CommandBindings.Add(new CommandBinding(Main.MultiProcessHTML,
                                    (s, e) => this.AppVM.MultiProcessHTMLDirectory(e,
                                                                     this.prgProgress,
                                                                     this.txtProgressStatus,
                                                                     null, this.lstStatus, null),
                                    (s, e) => this.AppVM.CanExecute_IfNoMultiProcessRuns(s, e)));

      CommandBindings.Add(new CommandBinding(Main.CancelMultiProcess,
                                    (s, e) => this.AppVM.CancelMultiProcessing(e)));
    }
    #endregion Methods
  }
}

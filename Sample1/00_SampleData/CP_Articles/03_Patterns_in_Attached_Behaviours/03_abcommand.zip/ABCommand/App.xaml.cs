﻿namespace ABCommand
{
  using System.Windows;
  using ABCommand.ViewModel;
  using System.Windows.Input;

  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
    private void Application_Startup(object sender, StartupEventArgs e)
    {
      // Construct ViewModel and MainWindow
      TestViewModel tVM = new TestViewModel();
      View.MainWindow win = new View.MainWindow();

      // Attach ViewModel to DataContext of ViewModel
      win.DataContext = tVM;

      this.InitMainWindowCommandBinding(win);

      // SHOW ME DA WINDOW!
      win.Show();
    }

  /// <summary>
  /// Initialize the RoutedCommand binding between MainWindow View and ViewModel
  /// </summary>
  /// <param name="win"></param>
  public void InitMainWindowCommandBinding(Window win)
  {
      win.CommandBindings.Add(new CommandBinding(AppCommand.LoadFile,
      (s, e) =>
      {
        if (e == null)
          return;

        string droppedFilePath = e.Parameter as string;

        if (droppedFilePath == null)
          return;

        ((TestViewModel)win.DataContext).LoadFile(droppedFilePath);

        e.Handled = true;
      }));
    }
  }
}

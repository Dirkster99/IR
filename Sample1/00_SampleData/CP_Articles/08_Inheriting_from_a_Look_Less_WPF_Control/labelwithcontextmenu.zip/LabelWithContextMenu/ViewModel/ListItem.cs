﻿namespace LabelWithContextMenu.ViewModel
{
  using LabelWithContextMenu.Unit;

  /// <summary>
  /// One item in the list of unit definition items
  /// </summary>
  public class ListItem
  {
    #region constructor
    public ListItem(Itemkey key, string displayNameLong, string displayNameShort)
    {
      this.Key = key;
      this.DisplayNameLong = (displayNameLong == null ? "(null)" : displayNameLong);
      this.DisplayNameShort = (displayNameShort == null ? "(null)" : displayNameShort);
    }

    protected ListItem()
    {
    }
    #endregion constructor

    #region properties
    public Itemkey Key { get; private set; }

    public string DisplayNameLong { get; private set; }
    public string DisplayNameShort { get; private set; }

    public string DisplayNameLongWithShort
    {
      get
      {
        return string.Format("{0} ({1})", this.DisplayNameShort, this.DisplayNameLong);
      }
    }
    #endregion properties
  }
}

﻿namespace LabelWithContextMenu.Behaviour
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;
  using System.Windows;
  using System.Windows.Controls;

  public class ContextMenuBehaviour
  {
    #region fields
    private static readonly DependencyProperty MenuListProperty =
        DependencyProperty.RegisterAttached("MenuList",
                                            typeof(ContextMenu),
                                            typeof(ContextMenuBehaviour),
                                            new UIPropertyMetadata(null, ContextMenuBehaviour.OnMenuListChanged));
    #endregion fields

    #region methods
    public static ContextMenu GetMenuList(DependencyObject obj)
    {
      return (ContextMenu)obj.GetValue(MenuListProperty);
    }

    public static void SetMenuList(DependencyObject obj, ContextMenu value)
    {
      obj.SetValue(MenuListProperty, value);
    }

    private static void OnMenuListChanged(DependencyObject d,
                                        DependencyPropertyChangedEventArgs e)
    {
      var element = d as FrameworkElement;

      if (element != null)
      {
        element.MouseLeftButtonUp += new System.Windows.Input.MouseButtonEventHandler(element_MouseLeftButtonUp);
      }
      else
        element.MouseLeftButtonUp -= element_MouseLeftButtonUp;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    static void element_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
      var element = sender as FrameworkElement;

      var target = ContextMenuBehaviour.GetMenuList(element) as ContextMenu;

      if (target != null)
      {
        // Open context menu defined through dependency property
        target.PlacementTarget = (UIElement)sender;
        target.IsOpen = true;
      }
      else
      {
        if (element != null)
        {
          // Open context menu on attached framework element
          element.ContextMenu.PlacementTarget = (UIElement)sender;
          element.ContextMenu.IsOpen = true;
        }
      }
    }
    #endregion methods
  }
}

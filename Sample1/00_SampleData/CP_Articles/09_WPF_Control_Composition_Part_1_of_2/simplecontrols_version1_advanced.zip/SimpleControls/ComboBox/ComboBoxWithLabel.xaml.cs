﻿namespace SimpleControls.ComboBox
{
  using System.Collections;
  using System.ComponentModel;
  using System.Collections.ObjectModel;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Data;
  using System.Windows.Media;

  /// <summary>
  /// Interaction logic for ComboBoxWithLabel.xaml
  /// </summary>
  public partial class ComboBoxWithLabel : UserControl
  {
    #region fields
    #region Label
    private static readonly DependencyProperty LabelContentProperty =
                            DependencyProperty.Register("LabelContent", typeof(string), typeof(ComboBoxWithLabel));

    private static readonly DependencyProperty LabelStyleProperty =
                            DependencyProperty.Register("LabelStyle", typeof(Style), typeof(ComboBoxWithLabel));
    #endregion Label

    #region ComboBox
    #region ComboBox
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.IsDropDownOpen dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.IsDropDownOpen dependency
    //     property.
    public static readonly DependencyProperty IsDropDownOpenProperty =
      ComboBox.IsDropDownOpenProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.IsEditable dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.IsEditable dependency
    //     property.
    public static readonly DependencyProperty IsEditableProperty =
      ComboBox.IsEditableProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.IsReadOnly dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.IsReadOnly dependency
    //     property.
    public static readonly DependencyProperty IsReadOnlyProperty =
      ComboBox.IsReadOnlyProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.MaxDropDownHeight dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.MaxDropDownHeight dependency
    //     property.
    public static readonly DependencyProperty MaxDropDownHeightProperty =
      ComboBox.MaxDropDownHeightProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.SelectionBoxItemTemplate dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.SelectionBoxItemTemplate dependency
    //     property.
    public static readonly DependencyProperty SelectionBoxItemTemplateProperty =
      ComboBox.SelectionBoxItemTemplateProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.StaysOpenOnEdit dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.StaysOpenOnEdit dependency
    //     property.
    public static readonly DependencyProperty StaysOpenOnEditProperty =
      ComboBox.StaysOpenOnEditProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ComboBox.Text dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ComboBox.Text dependency property.
    public static readonly DependencyProperty TextProperty =
      ComboBox.TextProperty.AddOwner(typeof(ComboBoxWithLabel));
    #endregion ComboBox

    #region Selector
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Primitives.Selector.IsSynchronizedWithCurrentItem dependency
    //     property
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Primitives.Selector.IsSynchronizedWithCurrentItem dependency
    //     property.
    public static readonly DependencyProperty IsSynchronizedWithCurrentItemProperty =
      ComboBox.IsSynchronizedWithCurrentItemProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Primitives.Selector.SelectedIndex dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Primitives.Selector.SelectedIndex dependency
    //     property.
    public static readonly DependencyProperty SelectedIndexProperty =
      ComboBox.SelectedIndexProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Primitives.Selector.SelectedItem dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Primitives.Selector.SelectedItem dependency
    //     property.
    public static readonly DependencyProperty SelectedItemProperty =
      ComboBox.SelectedItemProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Primitives.Selector.SelectedValuePath dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Primitives.Selector.SelectedValuePath dependency
    //     property.
    public static readonly DependencyProperty SelectedValuePathProperty =
      ComboBox.SelectedValuePathProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Primitives.Selector.SelectedValue dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Primitives.Selector.SelectedValue dependency
    //     property.
    public static readonly DependencyProperty SelectedValueProperty =
      ComboBox.SelectedValueProperty.AddOwner(typeof(ComboBoxWithLabel));
    #endregion Selector

    #region ItemsControl
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.AlternationCount dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.AlternationCount
    //     dependency property.
    public static readonly DependencyProperty AlternationCountProperty =
                            ComboBox.AlternationCountProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.DisplayMemberPath dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.DisplayMemberPath dependency
    //     property.
    public static readonly DependencyProperty DisplayMemberPathProperty =
                            ComboBox.DisplayMemberPathProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.GroupStyleSelector dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.GroupStyleSelector dependency
    //     property.
    public static readonly DependencyProperty GroupStyleSelectorProperty =
                            ComboBox.GroupStyleSelectorProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.HasItems dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.HasItems dependency
    //     property.
    public static readonly DependencyProperty HasItemsProperty =
                            ComboBox.HasItemsProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.IsGrouping dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.IsGrouping dependency
    //     property.
    public static readonly DependencyProperty IsGroupingProperty =
                            ComboBox.IsGroupingProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.IsTextSearchCaseSensitive
    //     dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.IsTextSearchCaseSensitive
    //     dependency property.
    public static readonly DependencyProperty IsTextSearchCaseSensitiveProperty =
                            ComboBox.IsTextSearchCaseSensitiveProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.IsTextSearchEnabled dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.IsTextSearchEnabled dependency
    //     property.
    public static readonly DependencyProperty IsTextSearchEnabledProperty =
                            ComboBox.IsTextSearchEnabledProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemBindingGroup dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemBindingGroup
    //     dependency property.
    public static readonly DependencyProperty ItemBindingGroupProperty =
                            ComboBox.ItemBindingGroupProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemContainerStyle dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemContainerStyle dependency
    //     property.
    public static readonly DependencyProperty ItemContainerStyleProperty =
                            ComboBox.ItemContainerStyleProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemContainerStyleSelector dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemContainerStyleSelector dependency
    //     property.
    public static readonly DependencyProperty ItemContainerStyleSelectorProperty =
                            ComboBox.ItemContainerStyleSelectorProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemsPanel dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemsPanel dependency
    //     property.
    public static readonly DependencyProperty ItemsPanelProperty =
                            ComboBox.ItemsPanelProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemsSource dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemsSource dependency
    //     property.
    public static readonly DependencyProperty ItemsSourceProperty =
                            ComboBox.ItemsSourceProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemStringFormat dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemStringFormat
    //     dependency property.
    public static readonly DependencyProperty ItemStringFormatProperty =
                            ComboBox.ItemStringFormatProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemTemplate dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemTemplate dependency
    //     property.
    public static readonly DependencyProperty ItemTemplateProperty =
                            ComboBox.ItemTemplateProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.ItemsControl.ItemTemplateSelector dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.ItemsControl.ItemTemplateSelector dependency
    //     property.
    public static readonly DependencyProperty ItemTemplateSelectorProperty =
                            ComboBox.ItemTemplateSelectorProperty.AddOwner(typeof(ComboBoxWithLabel));
    #endregion ItemsControl

    #region Control
    /***
    // Summary:
    //     Identifies the System.Windows.Controls.Control.Background dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.Background dependency
    //     property.
    public static readonly DependencyProperty CmbBackgroundProperty =
                           DependencyProperty.Register("CmbBackground", typeof(Brush), typeof(ComboBoxWithLabel));
    // Summary:
    //     Identifies the System.Windows.Controls.Control.BorderBrush dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.BorderBrush dependency
    //     property.
    public static readonly DependencyProperty CmbBorderBrushProperty =
                            ComboBox.BorderBrushProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.BorderThickness dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.BorderThickness dependency
    //     property.
    public static readonly DependencyProperty CmbBorderThicknessProperty =
                            ComboBox.BorderThicknessProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.FontFamily dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.FontFamily dependency
    //     property.
    public static readonly DependencyProperty CmbFontFamilyProperty =
                            ComboBox.FontFamilyProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.FontSize dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.FontSize dependency
    //     property.
    public static readonly DependencyProperty CmbFontSizeProperty =
                            ComboBox.FontSizeProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.FontStretch dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.FontStretch dependency
    //     property.
    public static readonly DependencyProperty CmbFontStretchProperty =
                            ComboBox.FontStretchProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.FontStyle dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.FontStyle dependency
    //     property.
    public static readonly DependencyProperty CmbFontStyleProperty =
                            ComboBox.FontStyleProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.FontWeight dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.FontWeight dependency
    //     property.
    public static readonly DependencyProperty CmbFontWeightProperty =
                            ComboBox.FontWeightProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.Foreground dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.Foreground dependency
    //     property.
    public static readonly DependencyProperty CmbForegroundProperty =
                            ComboBox.ForegroundProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.HorizontalContentAlignment dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.HorizontalContentAlignment dependency
    //     property.
    public static readonly DependencyProperty CmbHorizontalContentAlignmentProperty =
                            ComboBox.HorizontalContentAlignmentProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.IsTabStop dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.IsTabStop dependency
    //     property.
    public static readonly DependencyProperty CmbIsTabStopProperty =
                            ComboBox.IsTabStopProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.Padding dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.Padding dependency
    //     property.
    public static readonly DependencyProperty CmbPaddingProperty =
                            ComboBox.PaddingProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.TabIndex dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.TabIndex dependency
    //     property.
    public static readonly DependencyProperty CmbTabIndexProperty =
                            ComboBox.TabIndexProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.Template dependency property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.Template dependency
    //     property.
    public static readonly DependencyProperty CmbTemplateProperty =
                            ComboBox.TemplateProperty.AddOwner(typeof(ComboBoxWithLabel));
    //
    // Summary:
    //     Identifies the System.Windows.Controls.Control.VerticalContentAlignment dependency
    //     property.
    //
    // Returns:
    //     The identifier for the System.Windows.Controls.Control.VerticalContentAlignment dependency
    //     property.
    public static readonly DependencyProperty CmbVerticalContentAlignmentProperty =
                            ComboBox.VerticalContentAlignmentProperty.AddOwner(typeof(ComboBoxWithLabel));
 ***/
    #endregion Control
    #endregion ComboBox
    #endregion fields

    #region constructor
    public ComboBoxWithLabel()
    {
      this.InitializeComponent();
    }
    #endregion constructor

    #region properties
    #region Label
    /// <summary>
    /// Declare a new LabelContent property that can be bound as well
    /// The ComboBoxWithLable.xaml will bind the Label's content to this
    /// </summary>
    public string LabelContent
    {
      get { return (string)GetValue(ComboBoxWithLabel.LabelContentProperty); }
      set { SetValue(ComboBoxWithLabel.LabelContentProperty, value); }
    }

    public Style LabelStyle
    {
      get { return (Style)GetValue(ComboBoxWithLabel.LabelStyleProperty); }
      set { SetValue(ComboBoxWithLabel.LabelStyleProperty, value); }
    }
    #endregion Label

    #region Combobox
    #region Combobox
    //
    // Summary:
    //     Gets or sets a value that indicates whether the drop-down for a combo box
    //     is currently open.
    //
    // Returns:
    //     true if the drop-down is open; otherwise, false. The default is false.
    [Browsable(false)]
    [Category("Appearance")]
    [Bindable(true)]
    public bool IsDropDownOpen
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsDropDownOpenProperty); }
      set { SetValue(ComboBoxWithLabel.IsDropDownOpenProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a value that enables or disables editing of the text in text
    //     box of the System.Windows.Controls.ComboBox.
    //
    // Returns:
    //     true if the System.Windows.Controls.ComboBox can be edited; otherwise false.
    //     The default is false.
    public bool IsEditable
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsEditableProperty); }
      set { SetValue(ComboBoxWithLabel.IsEditableProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a value that enables selection-only mode, in which the contents
    //     of the combo box are selectable but not editable.
    //
    // Returns:
    //     true if the System.Windows.Controls.ComboBox is read-only; otherwise, false.
    //     The default is false.
    public bool IsReadOnly
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsReadOnlyProperty); }
      set { SetValue(ComboBoxWithLabel.IsReadOnlyProperty, value); }
    }
    //
    // Summary:
    //     Gets whether the System.Windows.Controls.ComboBox.SelectionBoxItem is highlighted.
    //
    // Returns:
    //     true if the System.Windows.Controls.ComboBox.SelectionBoxItem is highlighted;
    //     otherwise, false.
    //
    // Summary:
    //     Gets or sets the maximum height for a combo box drop-down.
    //
    // Returns:
    //     A double that represents the height that is retrieved or the height to set.
    //     The default value as defined to the property system is a calculated value
    //     based on taking a one-third fraction of the system max screen height parameters,
    //     but this default is potentially overridden by various control templates.
    [Bindable(true)]
    [TypeConverter(typeof(LengthConverter))]
    [Category("Layout")]
    public double MaxDropDownHeight
    {
      get { return (double)GetValue(ComboBoxWithLabel.MaxDropDownHeightProperty); }
      set { SetValue(ComboBoxWithLabel.MaxDropDownHeightProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets whether a System.Windows.Controls.ComboBox that is open and
    //     displays a drop-down control will remain open when a user clicks the System.Windows.Controls.TextBox.
    //
    // Returns:
    //     true to keep the drop-down control open when the user clicks on the text
    //     area to start editing; otherwise, false. The default is false.
    public bool StaysOpenOnEdit
    {
      get { return (bool)GetValue(ComboBoxWithLabel.StaysOpenOnEditProperty); }
      set { SetValue(ComboBoxWithLabel.StaysOpenOnEditProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the text of the currently selected item.
    //
    // Returns:
    //     The string of the currently selected item. The default is an empty string
    //     ("").
    public string Text
    {
      get { return (string)GetValue(ComboBoxWithLabel.TextProperty); }
      set { SetValue(ComboBoxWithLabel.TextProperty, value); }
    }
    #endregion Combobox

    #region Selector
    // Summary:
    //     Gets or sets a value that indicates whether a System.Windows.Controls.Primitives.Selector
    //     should keep the System.Windows.Controls.Primitives.Selector.SelectedItem
    //     synchronized with the current item in the System.Windows.Controls.ItemsControl.Items
    //     property.
    //
    // Returns:
    //     true if the System.Windows.Controls.Primitives.Selector.SelectedItem is always
    //     synchronized with the current item in the System.Windows.Controls.ItemCollection;
    //     false if the System.Windows.Controls.Primitives.Selector.SelectedItem is
    //     never synchronized with the current item; null if the System.Windows.Controls.Primitives.Selector.SelectedItem
    //     is synchronized with the current item only if the System.Windows.Controls.Primitives.Selector
    //     uses a System.Windows.Data.CollectionView. The default value is null.
    [TypeConverter("System.Windows.NullableBoolConverter, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null")]
    [Localizability(LocalizationCategory.NeverLocalize)]
    [Bindable(true)]
    [Category("Behavior")]
    public bool? IsSynchronizedWithCurrentItem
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsSynchronizedWithCurrentItemProperty); }
      set { SetValue(ComboBoxWithLabel.IsSynchronizedWithCurrentItemProperty, value); }
    }

    /// <summary>
    /// MSDN Reference: http://msdn.microsoft.com/en-us/library/system.windows.controls.combobox.aspx
    /// </summary>
    public int SelectedIndex
    {
      get { return (int)GetValue(ComboBoxWithLabel.SelectedIndexProperty); }
      set { SetValue(ComboBoxWithLabel.SelectedIndexProperty, value); }
    }
    /// <summary>
    /// MSDN Reference: http://msdn.microsoft.com/en-us/library/system.windows.controls.combobox.aspx
    /// </summary>
    public object SelectedItem
    {
      get { return (object)GetValue(ComboBoxWithLabel.SelectedItemProperty); }
      set { SetValue(ComboBoxWithLabel.SelectedItemProperty, value); }
    }

    /// <summary>
    /// MSDN Reference: http://msdn.microsoft.com/en-us/library/system.windows.controls.combobox.aspx
    /// </summary>
    public string SelectedValuePath
    {
      get { return (string)GetValue(ComboBoxWithLabel.SelectedValuePathProperty); }
      set { SetValue(ComboBoxWithLabel.SelectedValuePathProperty, value); }
    }

    /// <summary>
    /// MSDN Reference: http://msdn.microsoft.com/en-us/library/system.windows.controls.combobox.aspx
    /// </summary>
    public object SelectedValue
    {
      get { return (object)GetValue(ComboBoxWithLabel.SelectedValueProperty); }
      set { SetValue(ComboBoxWithLabel.SelectedValueProperty, value); }
    }
    #endregion Selector

    #region ItemsControl
    // Summary:
    //     Gets or sets the number of alternating item containers in the System.Windows.Controls.ItemsControl,
    //     which enables alternating containers to have a unique appearance.
    //
    // Returns:
    //     The number of alternating item containers in the System.Windows.Controls.ItemsControl.
    [Bindable(true)]
    public int AlternationCount
    {
      get { return (int)GetValue(ComboBoxWithLabel.AlternationCountProperty); }
      set { SetValue(ComboBoxWithLabel.AlternationCountProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a path to a value on the source object to serve as the visual
    //     representation of the object.
    //
    // Returns:
    //     The path to a value on the source object. This can be any path, or an XPath
    //     such as "@Name". The default is an empty string ("").
    [Bindable(true)]
    public string DisplayMemberPath
    {
      get { return (string)GetValue(ComboBoxWithLabel.DisplayMemberPathProperty); }
      set { SetValue(ComboBoxWithLabel.DisplayMemberPathProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a method that enables you to provide custom selection logic
    //     for a System.Windows.Controls.GroupStyle to apply to each group in a collection.
    //
    // Returns:
    //     A method that enables you to provide custom selection logic for a System.Windows.Controls.GroupStyle
    //     to apply to each group in a collection.
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Bindable(true)]
    public GroupStyleSelector GroupStyleSelector
    {
      get { return (GroupStyleSelector)GetValue(ComboBoxWithLabel.GroupStyleSelectorProperty); }
      set { SetValue(ComboBoxWithLabel.GroupStyleSelectorProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets a value that indicates whether case is a condition when searching
    //     for items.
    //
    // Returns:
    //     true if text searches are case-sensitive; otherwise, false.
    public bool IsTextSearchCaseSensitive
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsTextSearchCaseSensitiveProperty); }
      set { SetValue(ComboBoxWithLabel.IsTextSearchCaseSensitiveProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets a value that indicates whether System.Windows.Controls.TextSearch
    //     is enabled on the System.Windows.Controls.ItemsControl instance.
    //
    // Returns:
    //     true if System.Windows.Controls.TextSearch is enabled; otherwise, false.
    //     The default is false.
    public bool IsTextSearchEnabled
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsTextSearchEnabledProperty); }
      set { SetValue(ComboBoxWithLabel.IsTextSearchEnabledProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets the System.Windows.Data.BindingGroup that is copied to each
    //     item in the System.Windows.Controls.ItemsControl.
    //
    // Returns:
    //     The System.Windows.Data.BindingGroup that is copied to each item in the System.Windows.Controls.ItemsControl.
    [Bindable(true)]
    public BindingGroup ItemBindingGroup
    {
      get { return (BindingGroup)GetValue(ComboBoxWithLabel.ItemBindingGroupProperty); }
      set { SetValue(ComboBoxWithLabel.ItemBindingGroupProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets the System.Windows.Style that is applied to the container element
    //     generated for each item.
    //
    // Returns:
    //     The System.Windows.Style that is applied to the container element generated
    //     for each item. The default is null.
    [Bindable(true)]
    [Category("Content")]
    public Style ItemContainerStyle
    {
      get { return (Style)GetValue(ComboBoxWithLabel.ItemContainerStyleProperty); }
      set { SetValue(ComboBoxWithLabel.ItemContainerStyleProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets custom style-selection logic for a style that can be applied
    //     to each generated container element.
    //
    // Returns:
    //     A System.Windows.Controls.StyleSelector object that contains logic that chooses
    //     the style to use as the System.Windows.Controls.ItemsControl.ItemContainerStyle.
    //     The default is null.
    [Bindable(true)]
    [Category("Content")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public StyleSelector ItemContainerStyleSelector
    {
      get { return (StyleSelector)GetValue(ComboBoxWithLabel.ItemContainerStyleSelectorProperty); }
      set { SetValue(ComboBoxWithLabel.ItemContainerStyleSelectorProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets a collection used to generate the content of the System.Windows.Controls.ItemsControl.
    //
    // Returns:
    //     A collection that is used to generate the content of the System.Windows.Controls.ItemsControl.
    //     The default is null.
    [Bindable(true)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public IEnumerable ItemsSource
    {
      get { return (IEnumerable)GetValue(ComboBoxWithLabel.ItemsSourceProperty); }
      set { SetValue(ComboBoxWithLabel.ItemsSourceProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a composite string that specifies how to format the items in
    //     the System.Windows.Controls.ItemsControl if they are displayed as strings.
    //
    // Returns:
    //     A composite string that specifies how to format the items in the System.Windows.Controls.ItemsControl
    //     if they are displayed as strings.
    [Bindable(true)]
    public string ItemStringFormat
    {
      get { return (string)GetValue(ComboBoxWithLabel.ItemStringFormatProperty); }
      set { SetValue(ComboBoxWithLabel.ItemStringFormatProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets the System.Windows.DataTemplate used to display each item.
    //
    // Returns:
    //     A System.Windows.DataTemplate that specifies the visualization of the data
    //     objects. The default is null.
    [Bindable(true)]
    public DataTemplate ItemTemplate
    {
      get { return (DataTemplate)GetValue(ComboBoxWithLabel.ItemTemplateProperty); }
      set { SetValue(ComboBoxWithLabel.ItemTemplateProperty, value); }
    }

    //
    // Summary:
    //     Gets or sets the custom logic for choosing a template used to display each
    //     item.
    //
    // Returns:
    //     A custom System.Windows.Controls.DataTemplateSelector object that provides
    //     logic and returns a System.Windows.DataTemplate. The default is null.
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Bindable(true)]
    public DataTemplateSelector ItemTemplateSelector
    {
      get { return (DataTemplateSelector)GetValue(ComboBoxWithLabel.ItemTemplateSelectorProperty); }
      set { SetValue(ComboBoxWithLabel.ItemTemplateSelectorProperty, value); }
    }
    #endregion ItemsControl

    #region Control
    /***
    // Summary:
    //     Gets or sets a brush that describes the background of a control.
    //
    // Returns:
    //     The brush that is used to fill the background of the control. The default
    //     is System.Windows.Media.Brushes.Transparent.
    [Bindable(true)]
    [Category("Appearance")]
    public Brush CmbBackground
    {
      get { return (Brush)GetValue(ComboBoxWithLabel.CmbBackgroundProperty); }
      set { SetValue(ComboBoxWithLabel.CmbBackgroundProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a brush that describes the border background of a control.
    //
    // Returns:
    //     The brush that is used to fill the control's border; the default is System.Windows.Media.Brushes.Transparent.
    [Category("Appearance")]
    [Bindable(true)]
    public Brush CmbBorderBrush
    {
      get { return (Brush)GetValue(ComboBoxWithLabel.BorderBrushProperty); }
      set { SetValue(ComboBoxWithLabel.BorderBrushProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the border thickness of a control.
    //
    // Returns:
    //     A thickness value; the default is a thickness of 0 on all four sides.
    [Category("Appearance")]
    [Bindable(true)]
    public Thickness CmbBorderThickness
    {
      get { return (Thickness)GetValue(ComboBoxWithLabel.BorderThicknessProperty); }
      set { SetValue(ComboBoxWithLabel.BorderThicknessProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the font family of the control.
    //
    // Returns:
    //     A font family. The default is the system dialog font.
    [Bindable(true)]
    [Localizability(LocalizationCategory.Font)]
    [Category("Appearance")]
    public FontFamily CmbFontFamily
    {
      get { return (FontFamily)GetValue(ComboBoxWithLabel.FontFamilyProperty); }
      set { SetValue(ComboBoxWithLabel.FontFamilyProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the font size.
    //
    // Returns:
    //     The size of the text in the System.Windows.Controls.Control. The default
    //     is System.Windows.SystemFonts.MessageFontSize. The font size must be a positive
    //     number.
    [TypeConverter(typeof(FontSizeConverter))]
    [Localizability(LocalizationCategory.None)]
    [Bindable(true)]
    [Category("Appearance")]
    public double CmbFontSize
    {
      get { return (double)GetValue(ComboBoxWithLabel.FontSizeProperty); }
      set { SetValue(ComboBoxWithLabel.FontSizeProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the degree to which a font is condensed or expanded on the screen.
    //
    // Returns:
    //     A System.Windows.FontStretch value. The default is System.Windows.FontStretches.Normal.
    [Category("Appearance")]
    [Bindable(true)]
    public FontStretch CmbFontStretch
    {
      get { return (FontStretch)GetValue(ComboBoxWithLabel.FontStretchProperty); }
      set { SetValue(ComboBoxWithLabel.FontStretchProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the font style.
    //
    // Returns:
    //     A System.Windows.FontStyle value. The default is System.Windows.FontStyles.Normal.
    [Category("Appearance")]
    [Bindable(true)]
    public FontStyle CmbFontStyle
    {
      get { return (FontStyle)GetValue(ComboBoxWithLabel.FontStyleProperty); }
      set { SetValue(ComboBoxWithLabel.FontStyleProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the weight or thickness of the specified font.
    //
    // Returns:
    //     A System.Windows.FontWeight value. The default is System.Windows.FontWeights.Normal.
    [Bindable(true)]
    [Category("Appearance")]
    public FontWeight CmbFontWeight
    {
      get { return (FontWeight)GetValue(ComboBoxWithLabel.FontWeightProperty); }
      set { SetValue(ComboBoxWithLabel.FontWeightProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a brush that describes the foreground color.
    //
    // Returns:
    //     The brush that paints the foreground of the control. The default value is
    //     the system dialog font color.
    [Bindable(true)]
    [Category("Appearance")]
    public Brush CmbForeground
    {
      get { return (Brush)GetValue(ComboBoxWithLabel.ForegroundProperty); }
      set { SetValue(ComboBoxWithLabel.ForegroundProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the horizontal alignment of the control's content.
    //
    // Returns:
    //     One of the System.Windows.HorizontalAlignment values. The default is System.Windows.HorizontalAlignment.Left.
    [Bindable(true)]
    [Category("Layout")]
    public HorizontalAlignment CmbHorizontalContentAlignment
    {
      get { return (HorizontalAlignment)GetValue(ComboBoxWithLabel.HorizontalContentAlignmentProperty); }
      set { SetValue(ComboBoxWithLabel.HorizontalContentAlignmentProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a value that indicates whether a control is included in tab
    //     navigation.
    //
    // Returns:
    //     true if the control is included in tab navigation; otherwise, false. The
    //     default is true.
    [Bindable(true)]
    [Category("Behavior")]
    public bool CmbIsTabStop
    {
      get { return (bool)GetValue(ComboBoxWithLabel.IsTabStopProperty); }
      set { SetValue(ComboBoxWithLabel.IsTabStopProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the padding inside a control.
    //
    // Returns:
    //     The amount of space between the content of a System.Windows.Controls.Control
    //     and its System.Windows.FrameworkElement.Margin or System.Windows.Controls.Border.
    //     The default is a thickness of 0 on all four sides.
    [Category("Layout")]
    [Bindable(true)]
    public Thickness CmbPadding
    {
      get { return (Thickness)GetValue(ComboBoxWithLabel.PaddingProperty); }
      set { SetValue(ComboBoxWithLabel.PaddingProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a value that determines the order in which elements receive
    //     focus when the user navigates through controls by using the TAB key.
    //
    // Returns:
    //     A value that determines the order of logical navigation for a device. The
    //     default value is System.Int32.MaxValue.
    [Category("Behavior")]
    [Bindable(true)]
    public int CmbTabIndex
    {
      get { return (int)GetValue(ComboBoxWithLabel.TabIndexProperty); }
      set { SetValue(ComboBoxWithLabel.TabIndexProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets a control template.
    //
    // Returns:
    //     The template that defines the appearance of the System.Windows.Controls.Control.
    public ControlTemplate CmbTemplate
    {
      get { return (ControlTemplate)GetValue(ComboBoxWithLabel.TemplateProperty); }
      set { SetValue(ComboBoxWithLabel.TemplateProperty, value); }
    }
    //
    // Summary:
    //     Gets or sets the vertical alignment of the control's content.
    //
    // Returns:
    //     One of the System.Windows.VerticalAlignment values. The default is System.Windows.VerticalAlignment.Top.
    [Bindable(true)]
    [Category("Layout")]
    public VerticalAlignment CmbVerticalContentAlignment
    {
      get { return (VerticalAlignment)GetValue(ComboBoxWithLabel.VerticalContentAlignmentProperty); }
      set { SetValue(ComboBoxWithLabel.VerticalContentAlignmentProperty, value); }
    }
     ***/
    #endregion Control
    #endregion Combobox
    #endregion properties
  }
}

/******
FrameworkElement
----------------
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.ActualHeight dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.ActualHeight dependency
        //     property.
        public static readonly DependencyProperty ActualHeightProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.ActualWidth dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.ActualWidth dependency
        //     property.
        public static readonly DependencyProperty ActualWidthProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.BindingGroup dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.BindingGroup dependency
        //     property.
        public static readonly DependencyProperty BindingGroupProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.ContextMenu dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.ContextMenu dependency property identifier.
        public static readonly DependencyProperty ContextMenuProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Cursor dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Cursor dependency
        //     property.
        public static readonly DependencyProperty CursorProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.DataContext dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.DataContext dependency property identifier.
        public static readonly DependencyProperty DataContextProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.FlowDirection dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.FlowDirection dependency property identifier.
        [CommonDependencyProperty]
        public static readonly DependencyProperty FlowDirectionProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.FocusVisualStyle dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.FocusVisualStyle dependency
        //     property.
        public static readonly DependencyProperty FocusVisualStyleProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.ForceCursor dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.ForceCursor dependency
        //     property.
        public static readonly DependencyProperty ForceCursorProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Height dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Height dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty HeightProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.HorizontalAlignment dependency
        //     property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.HorizontalAlignment dependency property
        //     identifier.
        [CommonDependencyProperty]
        public static readonly DependencyProperty HorizontalAlignmentProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.InputScope dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.InputScope dependency
        //     property.
        public static readonly DependencyProperty InputScopeProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Language dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.Language dependency property identifier.
        public static readonly DependencyProperty LanguageProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.LayoutTransform dependency
        //     property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.LayoutTransform dependency property identifier.
        public static readonly DependencyProperty LayoutTransformProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Margin dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.Margin dependency property identifier.
        [CommonDependencyProperty]
        public static readonly DependencyProperty MarginProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.MaxHeight dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.MaxHeight dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty MaxHeightProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.MaxWidth dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.MaxWidth dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty MaxWidthProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.MinHeight dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.MinHeight dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty MinHeightProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.MinWidth dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.MinWidth dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty MinWidthProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Name dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Name dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty NameProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.OverridesDefaultStyle dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.OverridesDefaultStyle dependency
        //     property.
        public static readonly DependencyProperty OverridesDefaultStyleProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Style dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Style dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty StyleProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Tag dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Tag dependency property.
        public static readonly DependencyProperty TagProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.ToolTip dependency property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.ToolTip dependency property identifier.
        public static readonly DependencyProperty ToolTipProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.UseLayoutRounding dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.UseLayoutRounding dependency
        //     property.
        public static readonly DependencyProperty UseLayoutRoundingProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.VerticalAlignment dependency
        //     property.
        //
        // Returns:
        //     The System.Windows.FrameworkElement.VerticalAlignment dependency property
        //     identifier.
        [CommonDependencyProperty]
        public static readonly DependencyProperty VerticalAlignmentProperty;
        //
        // Summary:
        //     Identifies the System.Windows.FrameworkElement.Width dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.FrameworkElement.Width dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty WidthProperty;

UIElement
---------
        // Summary:
        //     Identifies the System.Windows.UIElement.AllowDrop dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.AllowDrop dependency property.
        public static readonly DependencyProperty AllowDropProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.AreAnyTouchesCaptured dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.AreAnyTouchesCaptured dependency
        //     property.
        public static readonly DependencyProperty AreAnyTouchesCapturedProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.AreAnyTouchesCapturedWithin dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.AreAnyTouchesCapturedWithin dependency
        //     property.
        public static readonly DependencyProperty AreAnyTouchesCapturedWithinProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.AreAnyTouchesDirectlyOver dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.AreAnyTouchesDirectlyOver dependency
        //     property.
        public static readonly DependencyProperty AreAnyTouchesDirectlyOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.AreAnyTouchesOver dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.AreAnyTouchesOver dependency
        //     property.
        public static readonly DependencyProperty AreAnyTouchesOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.BitmapEffectInput dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.BitmapEffectInput dependency property identifier.
        public static readonly DependencyProperty BitmapEffectInputProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.BitmapEffect dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.BitmapEffect dependency property identifier.
        public static readonly DependencyProperty BitmapEffectProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.CacheMode dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.CacheMode dependency property.
        public static readonly DependencyProperty CacheModeProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Clip dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Clip dependency property.
        public static readonly DependencyProperty ClipProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.ClipToBounds dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.ClipToBounds dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty ClipToBoundsProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Effect dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Effect dependency property.
        public static readonly DependencyProperty EffectProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Focusable dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Focusable dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty FocusableProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsEnabled dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsEnabled dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty IsEnabledProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsFocused dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsFocused dependency property identifier.
        public static readonly DependencyProperty IsFocusedProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsHitTestVisible  dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsHitTestVisible dependency property identifier.
        public static readonly DependencyProperty IsHitTestVisibleProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsKeyboardFocused dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsKeyboardFocused dependency
        //     property.
        public static readonly DependencyProperty IsKeyboardFocusedProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsKeyboardFocusWithin dependency
        //     property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsKeyboardFocusWithin dependency property identifier.
        public static readonly DependencyProperty IsKeyboardFocusWithinProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsManipulationEnabled dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsManipulationEnabled dependency
        //     property.
        public static readonly DependencyProperty IsManipulationEnabledProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsMouseCaptured dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsMouseCaptured dependency
        //     property.
        public static readonly DependencyProperty IsMouseCapturedProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsMouseCaptureWithin dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsMouseCaptureWithin dependency
        //     property.
        public static readonly DependencyProperty IsMouseCaptureWithinProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsMouseDirectlyOver dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsMouseDirectlyOver dependency
        //     property.
        public static readonly DependencyProperty IsMouseDirectlyOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsMouseOver dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsMouseOver dependency property identifier.
        public static readonly DependencyProperty IsMouseOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsStylusCaptured dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsStylusCaptured dependency
        //     property.
        public static readonly DependencyProperty IsStylusCapturedProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsStylusCaptureWithin dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsStylusCaptureWithin dependency
        //     property.
        public static readonly DependencyProperty IsStylusCaptureWithinProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsStylusDirectlyOver dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.IsStylusDirectlyOver dependency
        //     property.
        public static readonly DependencyProperty IsStylusDirectlyOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsStylusOver dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsStylusOver dependency property identifier.
        public static readonly DependencyProperty IsStylusOverProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.IsVisible dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.IsVisible dependency property identifier.
        public static readonly DependencyProperty IsVisibleProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.OpacityMask dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.OpacityMask dependency property.
        public static readonly DependencyProperty OpacityMaskProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Opacity dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Opacity dependency property.
        public static readonly DependencyProperty OpacityProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.RenderTransformOrigin dependency
        //     property.
        //
        // Returns:
        //     The System.Windows.UIElement.RenderTransformOrigin dependency property identifier.
        public static readonly DependencyProperty RenderTransformOriginProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.RenderTransform dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.RenderTransform dependency
        //     property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty RenderTransformProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.SnapsToDevicePixels dependency property.
        //
        // Returns:
        //     The System.Windows.UIElement.SnapsToDevicePixels dependency property identifier.
        public static readonly DependencyProperty SnapsToDevicePixelsProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Uid dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Uid dependency property.
        public static readonly DependencyProperty UidProperty;
        //
        // Summary:
        //     Identifies the System.Windows.UIElement.Visibility dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.UIElement.Visibility dependency property.
        [CommonDependencyProperty]
        public static readonly DependencyProperty VisibilityProperty;
*******/

/*******
FrameworkElement
----------------

        // Summary:
        //     Gets the rendered height of this element.
        //
        // Returns:
        //     The element's height, as a value in device-independent units (1/96th inch
        //     per unit). The default value is 0 (zero).
        public double ActualHeight { get; }
        //
        // Summary:
        //     Gets the rendered width of this element.
        //
        // Returns:
        //     The element's width, as a value in device-independent units (1/96th inch
        //     per unit). The default value is 0 (zero).
        public double ActualWidth { get; }
        //
        // Summary:
        //     Gets or sets the System.Windows.Data.BindingGroup that is used for the element.
        //
        // Returns:
        //     The System.Windows.Data.BindingGroup that is used for the element.
        [Localizability(LocalizationCategory.NeverLocalize)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public BindingGroup BindingGroup

        //
        // Summary:
        //     Gets or sets the context menu element that should appear whenever the context
        //     menu is requested through user interface (UI) from within this element.
        //
        // Returns:
        //     The context menu assigned to this element.
        public ContextMenu ContextMenu
        //
        // Summary:
        //     Gets or sets the cursor that displays when the mouse pointer is over this
        //     element.
        //
        // Returns:
        //     The cursor to display. The default value is defined as null per this dependency
        //     property. However, the practical default at run time will come from a variety
        //     of factors.
        public Cursor Cursor
        //
        // Summary:
        //     Gets or sets the data context for an element when it participates in data
        //     binding.
        //
        // Returns:
        //     The object to use as data context.
        [Localizability(LocalizationCategory.NeverLocalize)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public object DataContext

        //
        // Summary:
        //     Gets or sets the direction that text and other user interface (UI) elements
        //     flow within any parent element that controls their layout.
        //
        // Returns:
        //     The direction that text and other UI elements flow within their parent element,
        //     as a value of the enumeration. The default value is System.Windows.FlowDirection.LeftToRight.
        [Localizability(LocalizationCategory.None)]
        public FlowDirection FlowDirection
        //
        // Summary:
        //     Gets or sets a property that enables customization of appearance, effects,
        //     or other style characteristics that will apply to this element when it captures
        //     keyboard focus.
        //
        // Returns:
        //     The desired style to apply on focus. The default value as declared in the
        //     dependency property is an empty static System.Windows.Style. However, the
        //     effective value at run time is often (but not always) a style as supplied
        //     by theme support for controls.
        public Style FocusVisualStyle
        //
        // Summary:
        //     Gets or sets a value that indicates whether this System.Windows.FrameworkElement
        //     should force the user interface (UI) to render the cursor as declared by
        //     the System.Windows.FrameworkElement.Cursor property.
        //
        // Returns:
        //     true if cursor presentation while over this element is forced to use current
        //     System.Windows.FrameworkElement.Cursor settings for the cursor (including
        //     on all child elements); otherwise false. The default value is false.
        public bool ForceCursor
        //
        // Summary:
        //     Gets or sets the suggested height of the element.
        //
        // Returns:
        //     The height of the element, in device-independent units (1/96th inch per unit).
        //     The default value is System.Double.NaN. This value must be equal to or greater
        //     than 0.0. See Remarks for upper bound information.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double Height
        //
        // Summary:
        //     Gets or sets the horizontal alignment characteristics applied to this element
        //     when it is composed within a parent element, such as a panel or items control.
        //
        // Returns:
        //     A horizontal alignment setting, as a value of the enumeration. The default
        //     is System.Windows.HorizontalAlignment.Stretch.
        public HorizontalAlignment HorizontalAlignment
        //
        // Summary:
        //     Gets or sets the direction that text and other user interface (UI) elements
        //     flow within any parent element that controls their layout.
        //
        // Returns:
        //     The direction that text and other UI elements flow within their parent element,
        //     as a value of the enumeration. The default value is System.Windows.FlowDirection.LeftToRight.
        [Localizability(LocalizationCategory.None)]
        public FlowDirection FlowDirection
        //
        // Summary:
        //     Gets or sets a property that enables customization of appearance, effects,
        //     or other style characteristics that will apply to this element when it captures
        //     keyboard focus.
        //
        // Returns:
        //     The desired style to apply on focus. The default value as declared in the
        //     dependency property is an empty static System.Windows.Style. However, the
        //     effective value at run time is often (but not always) a style as supplied
        //     by theme support for controls.
        public Style FocusVisualStyle
        //
        // Summary:
        //     Gets or sets a value that indicates whether this System.Windows.FrameworkElement
        //     should force the user interface (UI) to render the cursor as declared by
        //     the System.Windows.FrameworkElement.Cursor property.
        //
        // Returns:
        //     true if cursor presentation while over this element is forced to use current
        //     System.Windows.FrameworkElement.Cursor settings for the cursor (including
        //     on all child elements); otherwise false. The default value is false.
        public bool ForceCursor
        //
        // Summary:
        //     Gets or sets the suggested height of the element.
        //
        // Returns:
        //     The height of the element, in device-independent units (1/96th inch per unit).
        //     The default value is System.Double.NaN. This value must be equal to or greater
        //     than 0.0. See Remarks for upper bound information.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double Height
        //
        // Summary:
        //     Gets or sets the horizontal alignment characteristics applied to this element
        //     when it is composed within a parent element, such as a panel or items control.
        //
        // Returns:
        //     A horizontal alignment setting, as a value of the enumeration. The default
        //     is System.Windows.HorizontalAlignment.Stretch.
        public HorizontalAlignment HorizontalAlignment
        //
        // Summary:
        //     Gets or sets the scope limits for property value inheritance and resource
        //     key lookup.
        //
        // Returns:
        //     A value of the enumeration. The default is System.Windows.InheritanceBehavior.Default.
        protected internal InheritanceBehavior InheritanceBehavior
        //
        // Summary:
        //     Gets or sets the context for input used by this System.Windows.FrameworkElement.
        //
        // Returns:
        //     The input scope, which modifies how input from alternative input methods
        //     is interpreted. The default value is null (which results in a default handling
        //     of commands).
        public InputScope InputScope
        //
        // Summary:
        //     Gets a value that indicates whether this element has been initialized, either
        //     during processing by a XAML processor, or by explicitly having its System.Windows.FrameworkElement.EndInit()
        //     method called.
        //
        // Returns:
        //     true if the element is initialized per the aforementioned XAML processing
        //     or method calls; otherwise, false.
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public bool IsInitialized { get; }
        //
        // Summary:
        //     Gets a value that indicates whether this element has been loaded for presentation.
        //
        // Returns:
        //     true if the current element is attached to an element tree; false if the
        //     element has never been attached to a loaded element tree.
        public bool IsLoaded { get; }
        //
        // Summary:
        //     Gets or sets localization/globalization language information that applies
        //     to an element.
        //
        // Returns:
        //     The language information for this element. The default value is an System.Windows.Markup.XmlLanguage
        //     with its System.Windows.Markup.XmlLanguage.IetfLanguageTag value set to the
        //     string "en-US".
        public XmlLanguage Language
        //
        // Summary:
        //     Gets or sets a graphics transformation that should apply to this element
        //     when layout is performed.
        //
        // Returns:
        //     The transform this element should use. The default is System.Windows.Media.Transform.Identity.
        public Transform LayoutTransform
        //
        // Summary:
        //     Gets or sets the outer margin of an element.
        //
        // Returns:
        //     Provides margin values for the element. The default value is a System.Windows.Thickness
        //     with all properties equal to 0 (zero).
        public Thickness Margin
        //
        // Summary:
        //     Gets or sets the maximum height constraint of the element.
        //
        // Returns:
        //     The maximum height of the element, in device-independent units (1/96th inch
        //     per unit). The default value is System.Double.PositiveInfinity. This value
        //     can be any value equal to or greater than 0.0. System.Double.PositiveInfinity
        //     is also valid.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double MaxHeight
        //
        // Summary:
        //     Gets or sets the maximum width constraint of the element.
        //
        // Returns:
        //     The maximum width of the element, in device-independent units (1/96th inch
        //     per unit). The default value is System.Double.PositiveInfinity. This value
        //     can be any value equal to or greater than 0.0. System.Double.PositiveInfinity
        //     is also valid.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double MaxWidth
        //
        // Summary:
        //     Gets or sets the minimum height constraint of the element.
        //
        // Returns:
        //     The minimum height of the element, in device-independent units (1/96th inch
        //     per unit). The default value is 0.0. This value can be any value equal to
        //     or greater than 0.0. However, System.Double.PositiveInfinity is NOT valid,
        //     nor is System.Double.NaN.
        [TypeConverter(typeof(LengthConverter))]
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        public double MinHeight
        //
        // Summary:
        //     Gets or sets the minimum width constraint of the element.
        //
        // Returns:
        //     The minimum width of the element, in device-independent units (1/96th inch
        //     per unit). The default value is 0.0. This value can be any value equal to
        //     or greater than 0.0. However, System.Double.PositiveInfinity is not valid,
        //     nor is System.Double.NaN.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double MinWidth
        //
        // Summary:
        //     Gets or sets the identifying name of the element. The name provides a reference
        //     so that code-behind, such as event handler code, can refer to a markup element
        //     after it is constructed during processing by a XAML processor.
        //
        // Returns:
        //     The name of the element. The default is an empty string.
        [DesignerSerializationOptions(DesignerSerializationOptions.SerializeAsAttribute)]
        [Localizability(LocalizationCategory.NeverLocalize)]
        [MergableProperty(false)]
        public string Name
        //
        // Summary:
        //     Gets or sets a value that indicates whether this element incorporates style
        //     properties from theme styles.
        //
        // Returns:
        //     true if this element does not use theme style properties; all style-originating
        //     properties come from local application styles, and theme style properties
        //     do not apply. false if application styles apply first, and then theme styles
        //     apply for properties that were not specifically set in application styles.
        //     The default is false.
        public bool OverridesDefaultStyle
        //
        // Summary:
        //     Gets or sets the style used by this element when it is rendered.
        //
        // Returns:
        //     The applied, nondefault style for the element, if present. Otherwise, null.
        //     The default for a default-constructed System.Windows.FrameworkElement is
        //     null.
        public Style Style
        //
        // Summary:
        //     Gets or sets an arbitrary object value that can be used to store custom information
        //     about this element.
        //
        // Returns:
        //     The intended value. This property has no default value.
        [Localizability(LocalizationCategory.NeverLocalize)]
        public object Tag
        //
        // Summary:
        //     Gets or sets the tool-tip object that is displayed for this element in the
        //     user interface (UI).
        //
        // Returns:
        //     The tooltip object. See Remarks below for details on why this parameter is
        //     not strongly typed.
        [Bindable(true)]
        [Category("Appearance")]
        [Localizability(LocalizationCategory.ToolTip)]
        public object ToolTip
        //
        // Summary:
        //     Gets or sets a value that indicates whether layout rounding should be applied
        //     to this element's size and position during layout.
        //
        // Returns:
        //     true if layout rounding is applied; otherwise, false. The default is false.
        public bool UseLayoutRounding
        //
        // Summary:
        //     Gets or sets the vertical alignment characteristics applied to this element
        //     when it is composed within a parent element such as a panel or items control.
        //
        // Returns:
        //     A vertical alignment setting. The default is System.Windows.VerticalAlignment.Stretch.
        public VerticalAlignment VerticalAlignment
        //
        // Summary:
        //     Gets or sets the width of the element.
        //
        // Returns:
        //     The width of the element, in device-independent units (1/96th inch per unit).
        //     The default value is System.Double.NaN. This value must be equal to or greater
        //     than 0.0. See Remarks for upper bound information.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double Width
		
		
        //
        // Summary:
        //     Gets or sets the width of the element.
        //
        // Returns:
        //     The width of the element, in device-independent units (1/96th inch per unit).
        //     The default value is System.Double.NaN. This value must be equal to or greater
        //     than 0.0. See Remarks for upper bound information.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        [TypeConverter(typeof(LengthConverter))]
        public double Width

UIElement
---------
		
        // Summary:
        //     Gets or sets a value indicating whether this element can be used as the target
        //     of a drag-and-drop operation.
        //
        // Returns:
        //     true if this element can be used as the target of a drag-and-drop operation;
        //     otherwise, false. The default value is false.
        public bool AllowDrop
        //
        // Summary:
        //     Gets a value that indicates whether at least one touch is captured to this
        //     element.
        //
        // Returns:
        //     true if at least one touch is captured to this element; otherwise, false.
        public bool AreAnyTouchesCaptured { get; }
        //
        // Summary:
        //     Gets a value that indicates whether at least one touch is captured to this
        //     element or to any child elements in its visual tree.
        //
        // Returns:
        //     true if at least one touch is captured to this element or any child elements
        //     in its visual tree; otherwise, false.
        public bool AreAnyTouchesCapturedWithin { get; }
        //
        // Summary:
        //     Gets a value that indicates whether at least one touch is pressed over this
        //     element.
        //
        // Returns:
        //     true if at least one touch is pressed over this element; otherwise, false.
        public bool AreAnyTouchesDirectlyOver { get; }
        //
        // Summary:
        //     Gets a value that indicates whether at least one touch is pressed over this
        //     element or any child elements in its visual tree.
        //
        // Returns:
        //     true if at least one touch is pressed over this element or any child elements
        //     in its visual tree; otherwise, false.
        public bool AreAnyTouchesOver { get; }
        //
        // Summary:
        //     Gets or sets a bitmap effect that applies directly to the rendered content
        //     for this element.
        //
        // Returns:
        //     The bitmap effect to apply.
        [Obsolete("BitmapEffects are deprecated and no longer function.  Consider using Effects where appropriate instead.")]
        public BitmapEffect BitmapEffect
        //
        // Summary:
        //     Gets or sets an input source for the bitmap effect that applies directly
        //     to the rendered content for this element.
        //
        // Returns:
        //     The source for bitmap effects.
        [Obsolete("BitmapEffects are deprecated and no longer function.  Consider using Effects where appropriate instead.")]
        public BitmapEffectInput BitmapEffectInput
        //
        // Summary:
        //     Gets or sets a cached representation of the System.Windows.UIElement.
        //
        // Returns:
        //     A System.Windows.Media.CacheMode that holds a cached representation of the
        //     System.Windows.UIElement.
        public CacheMode CacheMode
        //
        // Summary:
        //     Gets or sets the geometry used to define the outline of the contents of an
        //     element.
        //
        // Returns:
        //     The geometry to be used for clipping area sizing. The default is a null System.Windows.Media.Geometry.
        public Geometry Clip
        //
        // Summary:
        //     Gets or sets a value indicating whether to clip the content of this element
        //     (or content coming from the child elements of this element) to fit into the
        //     size of the containing element.
        //
        // Returns:
        //     true if the content should be clipped; otherwise, false. The default value
        //     is false.
        public bool ClipToBounds

        //
        // Summary:
        //     Gets or sets the bitmap effect to apply to the System.Windows.UIElement.
        //
        // Returns:
        //     An System.Windows.Media.Effects.Effect that represents the bitmap effect.
        public Effect Effect
        //
        // Summary:
        //     Gets or sets a value that indicates whether the element can receive focus.
        //
        // Returns:
        //     true if the element is focusable; otherwise false. The default is false,
        //     but see Remarks.
        public bool Focusable
        //
        // Summary:
        //     Gets or sets a value indicating whether this element is enabled in the user
        //     interface (UI).
        //
        // Returns:
        //     true if the element is enabled; otherwise, false. The default value is true.
        public bool IsEnabled
        //
        // Summary:
        //     Gets a value that determines whether this element has logical focus.
        //
        // Returns:
        //     true if this element has logical focus; otherwise, false.
        public bool IsFocused { get; }
        //
        // Summary:
        //     Gets or sets a value that declares whether this element can possibly be returned
        //     as a hit test result from some portion of its rendered content.
        //
        // Returns:
        //     true if this element could be returned as a hit test result from at least
        //     one point; otherwise, false. The default value is true.
        public bool IsHitTestVisible
        //
        // Summary:
        //     Gets a value indicating whether an input method system, such as an Input
        //     Method Editor (IME), is enabled for processing the input to this element.
        //
        // Returns:
        //     true if an input method is active; otherwise, false. The default value of
        //     the underlying attached property is true; however, this will be influenced
        //     by the actual state of input methods at runtime.
        public bool IsInputMethodEnabled { get; }
        //
        // Summary:
        //     Gets a value indicating whether this element has keyboard focus.
        //
        // Returns:
        //     true if this element has keyboard focus; otherwise, false. The default is
        //     false.
        public bool IsKeyboardFocused { get; }
        //
        // Summary:
        //     Gets a value indicating whether keyboard focus is anywhere within the element
        //     or its visual tree child elements.
        //
        // Returns:
        //     true if keyboard focus is on the element or its child elements; otherwise,
        //     false.
        public bool IsKeyboardFocusWithin { get; }
        //
        // Summary:
        //     Gets or sets a value that indicates whether manipulation events are enabled
        //     on this System.Windows.UIElement.
        //
        // Returns:
        //     true if manipulation events are enabled on this System.Windows.UIElement;
        //     otherwise, false. The default is false.
        [CustomCategory("Touch_Category")]
        public bool IsManipulationEnabled
        //
        // Summary:
        //     Gets a value indicating whether the current size returned by layout measure
        //     is valid.
        //
        // Returns:
        //     true if the measure pass of layout returned a valid and current value; otherwise,
        //     false.
        public bool IsMeasureValid { get; }
        //
        // Summary:
        //     Gets a value indicating whether the mouse is captured to this element.
        //
        // Returns:
        //     true if the element has mouse capture; otherwise, false. The default is false.
        public bool IsMouseCaptured { get; }
        //
        // Summary:
        //     Gets a value that determines whether mouse capture is held by this element
        //     or by child elements in its visual tree.
        //
        // Returns:
        //     true if this element or a contained element has mouse capture; otherwise,
        //     false.
        public bool IsMouseCaptureWithin { get; }
        //
        // Summary:
        //     Gets a value that indicates whether the position of the mouse pointer corresponds
        //     to hit test results, which take element compositing into account.
        //
        // Returns:
        //     true if the mouse pointer is over the same element result as a hit test;
        //     otherwise, false. The default is false.
        public bool IsMouseDirectlyOver { get; }
        //
        // Summary:
        //     Gets a value indicating whether the mouse pointer is located over this element
        //     (including child elements in the visual tree).
        //
        // Returns:
        //     true if mouse pointer is over the element or its child elements; otherwise,
        //     false. The default is false.
        public bool IsMouseOver { get; }
        //
        // Summary:
        //     Gets a value indicating whether the stylus is captured by this element.
        //
        // Returns:
        //     true if the element has stylus capture; otherwise, false. The default is
        //     false.
        public bool IsStylusCaptured { get; }
        //
        // Summary:
        //     Gets a value that determines whether stylus capture is held by this element,
        //     or an element within the element bounds and its visual tree.
        //
        // Returns:
        //     true if this element or a contained element has stylus capture; otherwise,
        //     false. The default is false.
        public bool IsStylusCaptureWithin { get; }
        //
        // Summary:
        //     Gets a value that indicates whether the stylus position corresponds to hit
        //     test results, which take element compositing into account.
        //
        // Returns:
        //     true if the stylus pointer is over the same element result as a hit test;
        //     otherwise, false. The default is false.
        public bool IsStylusDirectlyOver { get; }
        //
        // Summary:
        //     Gets a value indicating whether the stylus cursor is located over this element
        //     (including visual child elements).
        //
        // Returns:
        //     true if stylus cursor is over the element or its child elements; otherwise,
        //     false. The default is false.
        public bool IsStylusOver { get; }
        //
        // Summary:
        //     Gets a value indicating whether this element is visible in the user interface
        //     (UI).
        //
        // Returns:
        //     true if the element is visible; otherwise, false.
        public bool IsVisible { get; }
        //
        // Summary:
        //     Gets or sets the opacity factor applied to the entire System.Windows.UIElement
        //     when it is rendered in the user interface (UI).
        //
        // Returns:
        //     The opacity factor. Default opacity is 1.0. Expected values are between 0.0
        //     and 1.0.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        public double Opacity
        //
        // Summary:
        //     Gets or sets an opacity mask, as a System.Windows.Media.Brush implementation
        //     that is applied to any alpha-channel masking for the rendered content of
        //     this element.
        //
        // Returns:
        //     The brush to use for opacity masking.
        public Brush OpacityMask
        //
        // Summary:
        //     Gets or sets transform information that affects the rendering position of
        //     this element.
        //
        // Returns:
        //     Describes the specifics of the desired render transform. The default is System.Windows.Media.Transform.Identity.
        public Transform RenderTransform
        //
        // Summary:
        //     Gets or sets the center point of any possible render transform declared by
        //     System.Windows.UIElement.RenderTransform, relative to the bounds of the element.
        //
        // Returns:
        //     The value that declares the render transform. The default value is a System.Windows.Point
        //     with coordinates (0,0).
        public Point RenderTransformOrigin
        //
        // Summary:
        //     Gets or sets a value that determines whether rendering for this element should
        //     use device-specific pixel settings during rendering.
        //
        // Returns:
        //     true if the element should render in accordance to device pixels; otherwise,
        //     false. The default as declared on System.Windows.UIElement is false.
        public bool SnapsToDevicePixels
        //
        // Summary:
        //     Gets or sets the Uid for this element.
        //
        // Returns:
        //     A string that the Uid for this element.
        public string Uid
        //
        // Summary:
        //     Gets or sets the user interface (UI) visibility of this element.
        //
        // Returns:
        //     A value of the enumeration. The default value is System.Windows.Visibility.Visible.
        [Localizability(LocalizationCategory.None, Readability = Readability.Unreadable)]
        public Visibility Visibility
********/
﻿namespace FileSize_Converter_Test
{
  using System.Diagnostics;
  using System.Windows;

  using FSControls.FileSize;

  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>
  public partial class TestWindow : Window
  {
    public TestWindow()
    {
      this.InitializeComponent();
    }

    /// <summary>
    /// A hyperlink has been clicked. Start a web browser and let it browse to where this points to...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
    {
      Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
      e.Handled = true;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      NumberToSizeConverter conv = new NumberToSizeConverter();

      ulong[] minMax = (ulong[])this.FindResource("MinMaxValues");

      MessageBox.Show(string.Format("The input '{0}' is in the valid range and can be converted into the base unit: {1}.",
                                this.txtInput.Text,
                                conv.Convert(this.txtInput.Text, typeof(bool), minMax, null)),
                                "Conversion Info",
                                MessageBoxButton.OK, MessageBoxImage.Information);
    }

    /// <summary>
    /// Button click to show a different test window
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnTestWindow1_Click(object sender, RoutedEventArgs e)
    {
      TestDialog wnd = new TestDialog();
      ViewModel.ProgramOptionsVM MyViewModel = new ViewModel.ProgramOptionsVM();

      wnd.DataContext = new ViewModel.ProgramOptionsVM(MyViewModel);
      wnd.SetMinMax(MyViewModel.SelectedMemMin, MyViewModel.SelectedMemMax);
      wnd.ShowDialog();

      // Copy ViewModel if dialog was not cancelled
      if (wnd.bCancel == false)
        MyViewModel = wnd.DataContext as ViewModel.ProgramOptionsVM;

      ulong numberOfBytes = MyViewModel.SelectedMemSizeNumberOfBytes;

      MessageBox.Show(string.Format("The resulting value is: {0} {1} ({2} bytes)",
                                     MyViewModel.SelectedMemSize, MyViewModel.SelectedMemUnit, numberOfBytes),
                                    "Result",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
    }
  }
}

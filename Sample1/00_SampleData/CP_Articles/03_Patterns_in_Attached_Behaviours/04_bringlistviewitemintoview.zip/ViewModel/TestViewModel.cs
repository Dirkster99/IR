﻿namespace BringListViewItemIntoView.ViewModel
{
  using System;
  using System.Collections.ObjectModel;
  using System.Threading;
  using System.Threading.Tasks;
  using System.Windows.Threading;
  using System.Windows;

  class TestViewModel : ViewModelBase
  {
    private ObservableCollection<string> mMessages = null;
    private object mSelectedItem = null;

    public TestViewModel()
    {
      this.Messages = new ObservableCollection<string>();
    }

    public ObservableCollection<string> Messages
    {
      get
      {
        return this.mMessages;
      }

      private set
      {
        if (this.mMessages != value)
        {
          this.mMessages = value;
          this.NotifyPropertyChanged(() => this.Messages);
        }
      }
    }

    /// <summary>
    /// Get/set selected item in list of status messages displayed to the user.
    /// </summary>
    public object SelectedItem
    {
      get
      {
        return this.mSelectedItem;
      }

      set
      {
        if (this.mSelectedItem != value)
        {
          this.mSelectedItem = value;
          this.NotifyPropertyChanged(() => this.SelectedItem);
        }
      }
    }

    public void Processing()
    {
      this.SelectedItem = null;
      this.Messages.Clear();

      Task taskToProcess = null;
      taskToProcess = Task.Factory.StartNew<bool>((stateObj) =>
      {
        for (int i = 0; i < 15; i++)
        {
          string s = string.Format("Test Message {0} - Processing ...", i);

          // Editing the collection directly caused the Collection view to raise an exception
          // This type of CollectionView does not support changes to its SourceCollection from a thread different from the Dispatcher thread.
          // Bug, solution Source: http://stackoverflow.com/questions/2137769/wpf-where-do-i-get-a-threadsafe-collectionview
          Application.Current.Dispatcher.Invoke(
          System.Windows.Threading.DispatcherPriority.Normal,
          (Action)delegate
          {
            this.Messages.Add(s);
          });

          //System.Console.WriteLine(s);

          Thread.Sleep(500);
        }

        return true;                     // End of async task with summary list of result strings
      },
      null).ContinueWith(ant =>
      {
        this.ScrollLastResultIntoView();
      });
    }

    /// <summary>
    /// This procedure select's the last item in the list of message items
    /// (and an attached ListViewBehavour scrolls the selected item into view)
    /// </summary>
    protected void ScrollLastResultIntoView()
    {
      if (this.mMessages == null)
      {
        this.SelectedItem = null;
        return;
      }

      if (this.Messages.Count > 0)
        this.SelectedItem = this.Messages[this.Messages.Count - 1];
      else
        this.SelectedItem = null;
    }
  }
}

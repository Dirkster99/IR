﻿namespace Edi.View
{
  using System.Windows.Controls;

  /// <summary>
  /// Interaction logic for RecentFilesView.xaml
  /// </summary>
  public partial class RecentFilesView : UserControl
  {
    public RecentFilesView()
    {
      this.InitializeComponent();
    }
  }
}

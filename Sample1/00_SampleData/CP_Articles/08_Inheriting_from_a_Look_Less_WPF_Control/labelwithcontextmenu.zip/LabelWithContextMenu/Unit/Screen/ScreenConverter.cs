﻿namespace LabelWithContextMenu.Unit.Screen
{
  using System;
  
  public class ScreenConverter : Converter
  {
    /// <summary>
    /// A font size of 12 is equivalent to 100% (percent) display.
    /// </summary>
    public const double OneHundretPercent = 12.0;

    override public double Convert(Itemkey inputUnit, double inputValue, Itemkey outputUnit)
    {
      switch (inputUnit)
	    {
		    case Itemkey.ScreenFontPoints:
          return ScreenFontPoints.ToUnit(inputValue, outputUnit);

        case Itemkey.ScreenPercent:
          return ScreenPercent.ToUnit(inputValue, outputUnit);

        default:
          throw new NotImplementedException(outputUnit.ToString());
       }
    }
  }
}

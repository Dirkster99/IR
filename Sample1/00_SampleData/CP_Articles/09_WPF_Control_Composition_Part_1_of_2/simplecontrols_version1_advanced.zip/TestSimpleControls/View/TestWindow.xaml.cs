﻿namespace TestSimpleControls.View
{
  using System.Windows;

  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class TestWindow : Window
  {
    public TestWindow()
    {
      this.InitializeComponent();
    }
  }
}

﻿namespace WpfApplication1.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  class AppVM : Base.BaseVM 
  {
    private string mTestTitle = "Exposing inner Control properties for binding in WPF";
    private string mTestURL = "http://stackoverflow.com/questions/4169090/exposing-inner-control-properties-for-binding-in-wpf";

    public string TestTitle
    {
      get { return this.mTestTitle; }
    }

    public string TestURL
    {
        get { return this.mTestURL; }
    }
  }
}

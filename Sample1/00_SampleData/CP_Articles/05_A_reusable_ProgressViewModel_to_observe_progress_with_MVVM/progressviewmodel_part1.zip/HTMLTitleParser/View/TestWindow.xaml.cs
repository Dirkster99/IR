﻿namespace HTMLTitleParser.View
{
  using System.Diagnostics;
  using System.Windows;
  using System.Windows.Input;

  using ViewModel;

  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class TestWindow : Window
  {
    #region Constructor
    public TestWindow()
    {
      this.InitializeComponent();

      // Construct an ApplicationViewModel
      // initialize it from persistence
      // and attach it to the DataContext via AppVM property
      ViewModel.AppVM appVM = new ViewModel.AppVM();
      
      if (Properties.Settings.Default.InputDirectory != null)
        appVM.Path = Properties.Settings.Default.InputDirectory;

      this.AppVM = appVM;

      this.BindCommands();
    }
    #endregion Constructor

    #region Properties
    /// <summary>
    /// Wrap an ApplicationViewModel property around the DataContext of this
    /// (we do not use DataContext anywhere else directly because debugging
    /// is a nighmare otherwise ...)
    /// </summary>
    public AppVM AppVM
    {
      get
      {
        return this.DataContext as AppVM;
      }

      set
      {
        this.DataContext = value;
      }
    }
    #endregion Properties

    #region Methods
    /// <summary>
    /// A hyperlink has been clicked. Start a web browser and let it browse to where this points to...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
    {
      Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
      e.Handled = true;
    }

    /// <summary>
    /// Save current user settings on applciation shut down
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnWindowClosing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      Properties.Settings.Default.InputDirectory = ((AppVM)this.DataContext).Path;
      Properties.Settings.Default.Save();
    }

    /// <summary>
    /// Bind commands and background methods at run-time
    /// </summary>
    private void BindCommands()
    {
      // Bind ProcessHTML command to Application ViewModel method to execute when command executes
      // Progress properties are bound to the listed controls (dynamically at command runtime)
      CommandBindings.Add(new CommandBinding(Main.ProcessHTML,
                                    (s, e) => this.AppVM.ProcessHTMLDirectory(e,
                                                                     this.prgProgress,
                                                                     this.txtProgressStatus,
                                                                     null, this.lstStatus, null),
                                    (s, e) => this.AppVM.CanExecute_IfNoProcessRuns(s, e)));

      CommandBindings.Add(new CommandBinding(Main.CancelProcess,
                                    (s, e) => this.AppVM.CancelProcessing(e)));
    }
    #endregion Methods
  }
}

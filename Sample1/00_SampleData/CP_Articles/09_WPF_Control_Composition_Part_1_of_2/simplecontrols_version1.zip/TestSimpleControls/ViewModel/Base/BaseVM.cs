﻿namespace WpfApplication1.ViewModel.Base
{
  using System;
  using System.ComponentModel;
  using System.Linq.Expressions;

  /// <summary>
  /// Tell bound controls (via WPF binding) to refresh their display.
  /// 
  /// via call to:
  /// 
  /// this.NotifyPropertyChanged(() => this.Name);
  /// 
  /// Advantage: The property name is verified at compiler run-time.
  /// </summary>
  public class BaseVM : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged Members
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// Tell bound controls (via WPF binding) to refresh their display.
    /// 
    /// Sample call: this.NotifyPropertyChanged(() => this.IsSelected);
    /// where 'this' is derived from <seealso cref="BaseVM"/>
    /// and IsSelected is a property.
    /// </summary>
    /// <typeparam name="TProperty"></typeparam>
    /// <param name="property"></param>
    public void NotifyPropertyChanged<TProperty>(Expression<Func<TProperty>> property)
    {
      var lambda = (LambdaExpression)property;
      MemberExpression memberExpression;

      if (lambda.Body is UnaryExpression)
      {
        var unaryExpression = (UnaryExpression)lambda.Body;
        memberExpression = (MemberExpression)unaryExpression.Operand;
      }
      else
        memberExpression = (MemberExpression)lambda.Body;

      this.OnPropertyChanged(memberExpression.Member.Name);
    }
    
    /// <summary>
    /// Tell bound controls (via WPF binding) to refresh their display.
    /// 
    /// Sample call: this.OnPropertyChanged("IsSelected");
    /// where 'this' is derived from <seealso cref="BaseVM"/>
    /// and IsSelected is a property.
    /// </summary>
    /// <param name="propertyName">Name of property to refresh</param>
    protected virtual void OnPropertyChanged(string propertyName)
    {
      if (this.PropertyChanged != null)
        this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    #endregion INotifyPropertyChanged Members
  }
}

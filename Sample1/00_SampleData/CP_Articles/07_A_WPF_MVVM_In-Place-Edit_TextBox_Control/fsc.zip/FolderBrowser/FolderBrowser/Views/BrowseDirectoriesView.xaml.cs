namespace FolderBrowser.Views
{
  using System.Windows.Controls;

  /// <summary>
  /// Interaction logic for BrowseDirectoriesView.xaml
  /// </summary>
  public partial class BrowseDirectoriesView : UserControl
  {
	/// <summary>
	/// Class constructor
	/// </summary>
    public BrowseDirectoriesView()
    {
      this.InitializeComponent();
    }
  }
}

﻿namespace LabelWithContextMenu.ViewModel
{
  using System.Collections.ObjectModel;
  using LabelWithContextMenu.Unit;
  using LabelWithContextMenu.Unit.Distance;
  using LabelWithContextMenu.Unit.Screen;

  public class AppViewModel : BaseViewModel
  {
    #region constructor
    public AppViewModel()
    {
      this.Label1 = new UnitViewModel(this.GenerateDistanceUnitList(), new DistanceConverter(), 0);

      this.Label2 = new UnitViewModel(this.GenerateDistanceUnitList(), new DistanceConverter(), 0);

      this.SizeUnitLabel = new UnitViewModel(this.GenerateSizeUnitList(), new ScreenConverter(), 0);
    }
    #endregion constructor

    #region properties
    public UnitViewModel Label1 { get; set; }

    public UnitViewModel Label2 { get; set; }

    public UnitViewModel SizeUnitLabel { get; set; }
    #endregion properties

    #region methods
    private ObservableCollection<ListItem> GenerateDistanceUnitList()
    {
      ObservableCollection<ListItem> unitList = new ObservableCollection<ListItem>();

      unitList.Add(new ListItem(Itemkey.DisMetricKilometer, "kilometer", "km"));
      unitList.Add(new ListItem(Itemkey.DisMetricMeter, "meter", "m"));
      unitList.Add(new ListItem(Itemkey.DisMetricCentimeter, "centimeter", "cm"));
      unitList.Add(new ListItem(Itemkey.DisMetricMillimeter, "milimeter", "mm"));
      unitList.Add(new ListItem(Itemkey.DisMetricNanometer, "nanometer", "nm"));

      return unitList;    
    }

    private ObservableCollection<ListItem> GenerateSizeUnitList()
    {
      ObservableCollection<ListItem> unitList = new ObservableCollection<ListItem>();

      unitList.Add(new ListItem(Itemkey.ScreenPercent, "percent", "%"));
      unitList.Add(new ListItem(Itemkey.ScreenFontPoints, "points", "pt"));

      return unitList;
    }
    #endregion methods
  }
}

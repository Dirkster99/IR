﻿namespace LabelWithContextMenu.Unit.Distance.Metric
{
  using System;

  public sealed class Kilometer
  {
    private double mValue = 0;

    #region constructor
    public Kilometer(double value)
    {
      this.mValue = value;
    }

    private Kilometer()
    {
      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      Kilometer d = new Kilometer(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.DisMetricKilometer:
          return this.mValue;

        case Itemkey.DisMetricMeter:
          return this.mValue * 1000.0;

        case Itemkey.DisMetricCentimeter:
          return this.mValue * 100000.0;

        case Itemkey.DisMetricMillimeter:
          return this.mValue * 1000000.0;

        case Itemkey.DisMetricNanometer:
          return this.mValue * 1000000000000.0;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

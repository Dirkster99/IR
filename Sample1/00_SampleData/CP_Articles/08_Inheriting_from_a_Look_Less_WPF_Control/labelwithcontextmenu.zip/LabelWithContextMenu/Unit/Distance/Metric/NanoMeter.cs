﻿namespace LabelWithContextMenu.Unit.Distance.Metric
{
  using System;

  public sealed class NanoMeter
  {
    private double mValue = 0;

    #region constructor
    public NanoMeter(double value)
    {
      this.mValue = value;
    }

    private NanoMeter()
    {
      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      NanoMeter d = new NanoMeter(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.DisMetricKilometer:
          return this.mValue * (1 / 1000000000000.0);

        case Itemkey.DisMetricMeter:
          return this.mValue * (1 / 1000000000.0);

        case Itemkey.DisMetricCentimeter:
          return this.mValue * (1 / 10000000.0);

        case Itemkey.DisMetricMillimeter:
          return this.mValue * (1 / 1000000.0);

        case Itemkey.DisMetricNanometer:
          return this.mValue;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

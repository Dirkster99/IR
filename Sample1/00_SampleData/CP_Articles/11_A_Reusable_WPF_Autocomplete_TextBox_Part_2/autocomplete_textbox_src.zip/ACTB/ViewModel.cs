﻿namespace Aviad.WPF.Controls
{
  using System;
  using System.Collections;
  using System.Collections.Generic;
  using System.ComponentModel;

  /// <summary>
  /// The ViewModel of the suggestion list defines the text that is displayed
  /// in the textbox portions and the list that is shown in the drop down portion
  /// of of the AutoComplete textbox.
  /// </summary>
  [Serializable]
  public class ViewModel : INotifyPropertyChanged
  {
    /// <summary>
    /// Maximum number managed in manual list of unc paths '\\server\sharname\'
    /// </summary>
    private const int MaxSuggestionEntries = 128;

    #region fields
    [NonSerialized]
    private List<WaitMsg> mWaitMessage = new List<WaitMsg>() { new WaitMsg() };

    [NonSerialized]
    private string mQueryText = string.Empty;

    [NonSerialized]
    private IEnumerable mQueryCollection = null;

    [NonSerialized]
    private SortedList<string, int> mSuggestShare = new SortedList<string, int>();

    private List<string> mSuggestEntries = new List<string>();
    #endregion fields

    #region INotifyPropertyChanged Members
    public event PropertyChangedEventHandler PropertyChanged;
    #endregion

    #region properties
    /// <summary>
    /// Get list of entries (the user may have typed before) to suggest
    /// when nothing sensible and quickly to check has come up so far...
    /// (eg.: '\\server\share\')
    /// 
    /// Entries are case folded to upper case to allow for quick comparison
    /// in list (I know dictionaries can be used instead but this works as it is...)
    /// 
    /// Note: Use <seealso cref="AddListSuggest"/> to add an entry
    /// </summary>
    public List<string> SuggestEntries
    {
      get
      {
        return this.mSuggestEntries;
      }

      set
      {
        this.mSuggestEntries = new List<string>();
        this.mSuggestShare = new SortedList<string, int>();

        if (value != null)
        {
          for (int i = 0; i < value.Count && i < ViewModel.MaxSuggestionEntries; i++)
          {
            if (value[i] != null)
            {
              this.mSuggestEntries.Add(value[i].ToUpper());
              this.mSuggestShare.Add(value[i].ToUpper(), 1);
            }
          }
        }

        this.OnPropertyChanged(typeof(ViewModel).GetProperty("SuggestEntries").Name);
      }
    }

    /// <summary>
    /// Get a text drop-down indicating to the user that the system is busy...
    /// </summary>
    [System.Xml.Serialization.XmlIgnore]
    public IEnumerable WaitMessage
    {
      get { return this.mWaitMessage; }
    }

    /// <summary>
    /// Get/set the current text that is used in the query part of the drop-down
    /// section to determine the list of suggestions...
    /// </summary>
    [System.Xml.Serialization.XmlIgnore]
    public string QueryText
    {
      get
      {
        return this.mQueryText;
      }

      set
      {
        if (this.mQueryText != value)
        {
          this.mQueryText = value;
          this.OnPropertyChanged(typeof(ViewModel).GetProperty("QueryText").Name);
          this.mQueryCollection = null;
          this.OnPropertyChanged(typeof(ViewModel).GetProperty("QueryCollection").Name);
        }
      }
    }

    /// <summary>
    /// Get list of suggestions matching the string that a user had typed.
    /// </summary>
    [System.Xml.Serialization.XmlIgnore]
    public IEnumerable QueryCollection
    {
      get
      {
        this.QueryList(this.QueryText);
        return (this.mQueryCollection == null ? new List<string>() : this.mQueryCollection);
      }
    }
    #endregion properties

    #region methods
    /// <summary>
    /// Determine whether the given path contains a UNC path and return the name of the share if thats the case...
    /// </summary>
    /// <param name="sInPath"></param>
    /// <param name="sServerFolderShare"></param>
    /// <returns></returns>
    public bool GetServerFolderShare(string sInPath, out string sServerFolderShare)
    {
      sServerFolderShare = string.Empty;
      char cPathDel = '\\';

      if (sInPath == null) return false;

      if (sInPath.Length <= 8) return false;

      if (sInPath[0] != cPathDel || sInPath[1] != cPathDel) return false;

      int iServer = -1, iShare = -1;

      if ((iServer = sInPath.IndexOf(cPathDel, 2)) == -1) return false;

      if ((iShare = sInPath.IndexOf(cPathDel, iServer + 1)) == -1)
      {
        if (System.IO.Directory.Exists(sInPath))      // String is of the form: '\\Server\SharedFolder'
        {                                            // which is still OK
          sServerFolderShare = sInPath.ToUpper() + cPathDel;
          return true;
        }
        else
          return false;
      }

      sServerFolderShare = sInPath.ToUpper().Substring(0, iShare + 1);
      return true;
    }

    /// <summary>
    /// Standard method of the <seealso cref="INotifyPropertyChanged"/> interface
    /// which is used to tell subscribers of the ViewModel when the value of a property
    /// has changed.
    /// </summary>
    /// <param name="prop"></param>
    protected void OnPropertyChanged(string prop)
    {
      if (this.PropertyChanged != null)
        this.PropertyChanged(this, new PropertyChangedEventArgs(prop));
    }

    /// <summary>
    /// Add another string suggestion to the list of suggestions...
    /// </summary>
    /// <param name="s"></param>
    protected void AddListSuggest(string s)
    {
      if (s != null)
      {
        if (s.Trim().Length > 0)
        if (this.mSuggestShare.ContainsKey(s) == false)
        {
          // Increment frequency if entry is already avaliable
          // Otherwise, remove first or least frequency item and add new entry to keep list size at limit
          if (this.mSuggestShare.Count < ViewModel.MaxSuggestionEntries)
          {
            this.mSuggestEntries.Add(s.ToUpper());
            this.mSuggestShare.Add(s.ToUpper(), 1);
          }
          else
          {
            int iMinIdx = 0;
            for (int i = 0; i < this.mSuggestShare.Count; i++)
            {
              if (this.mSuggestShare.Values[i] < this.mSuggestShare.Values[iMinIdx])
              {
                iMinIdx = i;
              }
            }

            this.mSuggestEntries.RemoveAt(iMinIdx);
            this.mSuggestShare.RemoveAt(iMinIdx);

            this.mSuggestEntries.Add(s.ToUpper());
            this.mSuggestShare.Add(s.ToUpper(), 1);
          }
        }
        else                                       
        {
          this.mSuggestShare[s.ToUpper()] += 1;
        }
      }
    }

    /// <summary>
    /// This methode executes when the textbox content is changed
    /// and the system attempts to suggest a useful list of drop-down values.
    /// </summary>
    /// <param name="searchPath">Path to generate list of suggetsions for.</param>
    private void QueryList(string searchPath)
    {
      char sPathDel = System.IO.Path.DirectorySeparatorChar;
      string sServerFolderShare;

      List<string> sRet = null;

      try
      {
        // Simpley use this to test whether query is asynchrone to UI or not
        ////System.Threading.Thread.Sleep(5000);

        // suggest list of drives if user has not typed anything, yet
        if ((searchPath == null ? string.Empty : searchPath).Length <= 1)
        {
          sRet = new List<string>(System.IO.Directory.GetLogicalDrives());
        }
        else
        {
          if ((searchPath == null ? string.Empty : searchPath).Length == 2)
          {
            if (searchPath[1] == ':')
            {
              sRet = new List<string>(System.IO.Directory.GetDirectories(searchPath + sPathDel));
            }
            else
            {
              // Suggest shares on a UNC path addressed computer
              sRet = this.SuggestEntries;
            }
          }
          else
          {
            bool bQueryUNCShares = false;
            string sFileServer = string.Empty;

            // Determine whether this is a UNC Path without any share (just the server portion of it)
            if (searchPath.Length > 3)
            {
              if (searchPath[0] == '\\' && searchPath[1] == '\\' && searchPath[searchPath.Length - 1] == '\\' &&
                   searchPath.Substring(2, searchPath.Length - 3).Contains("\\") == false)
                {
                  bQueryUNCShares = true;
                  sFileServer = searchPath.Substring(2, searchPath.Length - 3);
                }
            }

            if (bQueryUNCShares == true) // query for shared folders on a file server via UNC
            {
              ShareCollection sc = new ShareCollection(sFileServer);
              
              if (sc.Count > 0)
              {
                sRet = new List<string>();
                foreach (Share s in sc)
                {
                  if (s.IsFileSystem)
                  {
                    sRet.Add(s.ToString());

                    // Add server to list of suggestions for next time when accessing this UNC address
                    this.AddListSuggest("\\\\" + s.Server + "\\");
                  }
                }
              }
            }
            else
            {
              if (System.IO.Directory.Exists(searchPath))
              {
                sRet = new List<string>(System.IO.Directory.GetDirectories(searchPath));

                if (sRet.Count > 0)
                if (this.GetServerFolderShare(searchPath, out sServerFolderShare))
                {
                  // Add server + share to list of suggestions for next time when accessing this address
                  this.AddListSuggest(sServerFolderShare);
                }
              }
              else
              {
                int idx = searchPath.LastIndexOf(System.IO.Path.DirectorySeparatorChar);

                if (idx > 0)
                {
                  string sParentDir = searchPath.Substring(0, idx + 1);
                  string sSearchPattern = searchPath.Substring(idx + 1) + "*";
                  sRet = new List<string>(System.IO.Directory.GetDirectories(sParentDir, sSearchPattern));
                }
              }
            }
          }
        }
      }
      catch
      {
      }

      // Determine whether collection changed to comparison to current data
      // and change it only if it is indeed different
      // (this saves messaging and event overheads that would othwise produce
      //  the same results multiple times causing overheads and oddities nobody needs...
      bool bChange = (sRet == null && this.mQueryCollection != null) ||
                      (sRet != null && this.mQueryCollection == null);

      if (sRet != null && this.mQueryCollection != null)
        bChange = (sRet == this.mQueryCollection);

      if (bChange == true)
        this.mQueryCollection = sRet;
    }
    #endregion methods

    /// <summary>
    /// We use this class wrapped in a List collection to pop-up a message while
    /// the background query is running...
    /// </summary>
    internal class WaitMsg
    {
      public override string ToString()
      {
        return "Please Wait...";
      }
    }
  }
}

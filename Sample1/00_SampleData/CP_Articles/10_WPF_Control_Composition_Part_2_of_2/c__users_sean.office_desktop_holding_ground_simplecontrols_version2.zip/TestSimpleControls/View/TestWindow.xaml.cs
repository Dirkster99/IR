﻿namespace TestSimpleControls.View
{
  using System;
  using System.Diagnostics;
  using System.Windows;
  using System.Windows.Input;

  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class TestWindow : Window
  {
    #region fields
    /// <summary>
    /// Array of resource definition files for each application theme
    /// 
    /// <seealso cref="TypeOfTheme"/>
    /// </summary>
    private static readonly string[] ThemeResourceUris =
    {
      "TestSimpleControls;component/Themes/ExpressionDark/ExpressionDark.xaml",
      "TestSimpleControls;component/Themes/Generic.xaml",
      "TestSimpleControls;component/Themes/WhistlerBlue/WhistlerBlue.xaml"
    };
    #endregion fields

    #region Constructor
    public TestWindow()
    {
      this.InitializeComponent();

      this.CurrentTheme = TypeOfTheme.Generic;
    }
    #endregion Constructor

    #region enums
    /// <summary>
    /// Enumeration for supported application themes
    /// 
    /// These types must be consistent with the <seealso cref="ThemeResourceUris"/> array.
    /// </summary>
    public enum TypeOfTheme
    {
      ExpressionDark = 0,
      Generic = 1,
      WhistlerBlue = 2
    }
    #endregion enums

    #region ThemingProperties
    /// <summary>
    /// Get the enum datatype of the currently selected theme
    /// </summary>
    public TypeOfTheme CurrentTheme
    {
      get;
      private set;
    }

    /// <summary>
    /// Get the name of the currently selected theme
    /// </summary>
    public string CurrentThemeName
    {
      get
      {
        return this.CurrentTheme.ToString();
      }
    }
    #endregion ThemingProperties

    #region Methods
    #region Theming
    /// <summary>
    /// Convert a enum data taype into a resource URI pointing at the source XAML theme file.
    /// 
    /// (throws an ArgumentOutOfRange Exception if enum cannot be mapped to a valid resource file)
    /// </summary>
    /// <param name="myTheme"></param>
    /// <returns></returns>
    internal static string MapThemeEnumToSourceFile(TypeOfTheme myTheme)
    {
      return ThemeResourceUris[(int)myTheme];
    }

    private void ChangeThemeCommand_Executed(object sender, ExecutedRoutedEventArgs e)
    {
      string sParameter = e.Parameter as string;

      if (sParameter == null) return;

      int i = 0;
      bool bFound = false;
      foreach (TestWindow.TypeOfTheme t in Enum.GetValues(typeof(TestWindow.TypeOfTheme)))
      {
        if (t.ToString().ToLower() == sParameter.ToLower())
        {
          this.CurrentTheme = t;
          bFound = true;
          break;
        }

        i++;
      }

      if (bFound == false)
        throw new NotImplementedException(sParameter);

      string sThemeResourceUrl = TestWindow.MapThemeEnumToSourceFile(this.CurrentTheme);

      ResourceDictionary skin = new ResourceDictionary();
      skin.Source = new Uri(sThemeResourceUrl, UriKind.RelativeOrAbsolute);
      Application.Current.Resources.MergedDictionaries.Clear();
      Application.Current.Resources.MergedDictionaries.Add(skin);
    }
    #endregion Theming

    #region Application Close Command
    /// <summary>
    /// Close the application and shutdown everything for now...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    private void Close_CommandExecuted(object sender, ExecutedRoutedEventArgs args)
    {
      this.Close(); // OnClosing EventHandler could check whether there is anything to save and save it...
    }
    #endregion Application Close Command
    #endregion Methods
  }
}

﻿namespace UnitComboLib.Unit.Temperature
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  public class TemperaturCelsius
  {
    private double mValue = 0;

    #region constructor
    public TemperaturCelsius(double value)
    {
      this.mValue = value;
    }

    private TemperaturCelsius()
    {      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      TemperaturCelsius d = new TemperaturCelsius(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.TemperaturCelsius:
          return this.mValue;

        case Itemkey.TemperaturDegreeFahrenheit:
          return (( this.mValue * 9 ) / 5 ) + 32;

        case Itemkey.TemperaturKelvin:
          return this.mValue + 273.15;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

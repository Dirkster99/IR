﻿namespace TestSimpleControls.View
{
  using System;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Input;

  /// <summary>
  /// This class customizes the WPF environment to manage
  /// the global command framework for the application.
  /// </summary>
  public class MainCommands
  {
    #region CommandFramework Fields
    private static RoutedUICommand exit;
    private static RoutedUICommand viewTheme;
    #endregion CommandFramework Fields

    #region Static Constructor
    /// <summary>
    /// Define custom commands and their key gestures
    /// </summary>
    static MainCommands()
    {
      InputGestureCollection inputs = new InputGestureCollection();      // Initialize the Exit command
      inputs.Add(new KeyGesture(Key.F4, ModifierKeys.Alt, "Alt+F4"));
      MainCommands.exit = new RoutedUICommand("Exit Program", "Exit", typeof(MainCommands), inputs);

      inputs = new InputGestureCollection();      // Initialize the theming command
      ////inputs.Add(new KeyGesture(Key.V, ModifierKeys.Alt, "Alt+V"));
      MainCommands.viewTheme = new RoutedUICommand("View Theme", "ViewTheme", typeof(MainCommands), inputs);
    }
    #endregion Static Constructor

    #region CommandFramwork_Properties
    public static RoutedUICommand Exit
    {
      get { return MainCommands.exit; }
    }

    public static RoutedUICommand ViewTheme
    {
      get { return MainCommands.viewTheme; }
    }
    #endregion CommandFramwork_Properties
  }
}

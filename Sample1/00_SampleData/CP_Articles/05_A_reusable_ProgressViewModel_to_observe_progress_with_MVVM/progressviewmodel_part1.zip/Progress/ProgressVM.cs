﻿namespace Progress
{
  using System;
  using System.Collections.Generic;
  using System.Collections.ObjectModel;
  using System.Threading;
  using System.Threading.Tasks;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Data;
  using System.Windows.Threading;

  /// <summary>
  /// The <see cref="ProgressVM"/> is a base class for implementing an ObserverViewModel class.
  /// An ObserverViewModel class is a class that can manage asynchronous task processing
  /// while exposing properties and methods necessary to:
  /// 
  /// - Display progress
  /// - Cancel the background thread
  /// - Disable/Enable controls for starting and stopping background processing
  /// </summary>
  public class ProgressVM : BaseVM
  {
    #region Fields
    #region PUBLIC ERROR CONSTANTS
    /// <summary>
    /// The process returns this result if everything was processed OK
    /// </summary>
    public const int OkNoError = 0;

    /// <summary>
    /// Initial value of result variable
    /// </summary>
    public const int InitValue = -1;

    /// <summary>
    /// The process returns this result if something went wrong
    /// </summary>
    public const int Failed = -2;

    /// <summary>
    /// Return this ResultCode if process was cancelled
    /// </summary>
    public const int Cancelled = -3;
    #endregion PUBLIC ERROR CONSTANTS

    /// <summary>
    /// Ready message to tell the user that the system is waiting for input.
    /// </summary>
    public const string StrReady = "Ready.";

    private static TFormat mTStampFormat = TFormat.DateTime;

    private string mStatusMessage = string.Empty;
    #region ProgressBar properties
    private int mMinProgress;
    private int mMaxProgress;
    private int mCurrentProgress;

    private ObservableCollection<string> mMessage;
    #endregion ProgressBar properties

    private CancellationTokenSource mCancelTokenSource = null;

    /// <summary>
    /// This property is used to tell the context of the thread that started this thread
    /// originally. We use this to generate callbacks in the correct context when the long
    /// running task is done.
    /// 
    /// Quote:
    /// One of the most important parts of this pattern is calling the MethodNameCompleted
    /// method on the same thread that called the MethodNameAsync method to begin with. You
    /// could do this using WPF fairly easily, by storing CurrentDispatcher—but then the
    /// nongraphical component could only be used in WPF applications, not in Windows Forms
    /// or ASP.NET programs. 
    /// 
    /// The DispatcherSynchronizationContext class addresses this need—think of it as a
    /// simplified version of Dispatcher that works with other UI frameworks as well.
    /// 
    /// http://msdn.microsoft.com/en-us/library/ms741870.aspx
    /// </summary>
    private DispatcherSynchronizationContext mRequestingContext = null;

    /// <summary>
    /// Determine whether a process can be executed or not
    /// </summary>
    private bool mCanRunProcess;

    /// <summary>
    /// Determine whether a cancel processing is possible or not
    /// </summary>
    private bool mCanCancelProcess;

    #region ErrorHandling
    private bool mAbortedWithErrors,    // These fields are use to note whether execution was:
                 mAbortedWithCancel;   // OK, Cancelled, or ended through errors

    private Exception mInnerException = null;
    #endregion ErrorHandling

    private int mResultCode = ProgressVM.InitValue;

    private Dictionary<string, object> mResultObjects = new Dictionary<string, object>();
    #endregion Fields

    #region Constructor
    /// <summary>
    /// Default Constructor of the progress observer base class
    /// </summary>
    public ProgressVM()
    {
      this.mStatusMessage = ProgressVM.StrReady;

      this.mMinProgress = 0;
      this.mMaxProgress = 100;
      this.mCurrentProgress = 0;
      this.mMessage = new ObservableCollection<string>();

      this.mCancelTokenSource = null;
      this.mCanRunProcess = true;
      this.mCanCancelProcess = !this.mCanRunProcess;

      this.mAbortedWithErrors = false;
      this.mAbortedWithCancel = false;
    }
    #endregion

    #region Events
    /// <summary>
    /// Event that tells calling thread when execution of async thread is complete.
    /// </summary>
    public event EventHandler<ProgressResult> resultEvent;
    #endregion Events

    #region DATE, TIME, AND DATETIME FORMAT
    /// <summary>
    /// Select a DateTime, Date, or Time format for
    /// <see cref="TStamp"/> output functions.
    /// </summary>
    public enum TFormat
    {
      /// <summary>
      /// Ouptut date and time portion in one formated string
      /// </summary>
      DateTime = 1,

      /// <summary>
      /// Ouptut only time portion in one formated string
      /// </summary>
      Time = 2,

      /// <summary>
      /// Ouptut only date portion in one formated string
      /// </summary>
      Date = 3
    }
    #endregion DATE, TIME, AND DATETIME FORMAT

    #region Properties
    /// <summary>
    /// Get/set time stamp formats in date, time, or datetime format
    /// </summary>
    public static TFormat TStampFormat
    {
      get { return ProgressVM.mTStampFormat; }
      set { ProgressVM.mTStampFormat = value; }
    }

    /// <summary>
    /// Simple utility function to generate a time stamp for 'timed' output
    /// </summary>
    /// <returns></returns>
    public static string TStamp
    {
      get
      {
        switch (ProgressVM.TStampFormat)
        {
          case TFormat.Date:
            return "[" + DateTime.Now.ToString("yyyy-MM-dd") + "] ";

          case TFormat.DateTime:
            return "[" + DateTime.Now.ToString("yyyy-MM-dd-HH:mm:ss") + "] ";

          case TFormat.Time:
            return "[" + DateTime.Now.ToString("HH:mm:ss") + "] ";

          default:
            return string.Format("TimeStamp format: '{0}' is not supported.",
                                 ProgressVM.TStampFormat.ToString());
        }
      }
    }

    /// <summary>
    /// Get the name of the process (being executed) so that it may be used in the GUI.
    /// </summary>
    public virtual string ProcessName
    {
      get
      {
        return "ProcessVM";
      }
    }

    /// <summary>
    /// Get property to get the resultcode of a progress run
    /// </summary>
    public int ResultCode
    {
      get { return this.mResultCode; }
      protected set { this.mResultCode = value; }
    }

    /// <summary>
    /// Get/set string being displayed to document current status in progress of processing.
    /// </summary>
    public string StatusMessage
    {
      get
      {
        return this.mStatusMessage;
      }

      set
      {
        this.mStatusMessage = value;
        this.OnPropertyChanged(Bind.PropName(() => this.StatusMessage));
      }
    }

    /// <summary>
    /// List all important messages accumolated over one process run
    /// </summary>
    public ObservableCollection<string> Message
    {
      get
      {
        return this.mMessage;
      }
     
      set
      {
        if (this.mMessage != value)
        {
          this.mMessage = (value == null ? new ObservableCollection<string>() : value);
          this.OnPropertyChanged(Bind.PropName(() => this.Message));
        }
      }
    }
    #region ProgressBar properties
    /// <summary>
    /// Get/set minimum value being displayed in bound progress bar object
    /// </summary>
    public int ProgressMin
    {
      get
      {
        return this.mMinProgress;
      }

      set
      {
        this.mMinProgress = value;

        if (this.mMinProgress < this.mCurrentProgress)  // Current progress should be smaller/equal than MaxProgress
          this.mCurrentProgress = this.mMinProgress;

        this.OnPropertyChanged(Bind.PropName(() => this.ProgressMin));
      }
    }

    /// <summary>
    /// Get/set maximum value being displayed in bound progress bar object
    /// </summary>
    public int ProgressMax
    {
      get
      {
        return this.mMaxProgress;
      }

      set
      {
        this.mMaxProgress = value;

        if (this.ProgressMax < this.mCurrentProgress)  // Current progress should be smaller/equal than MaxProgress
          this.mCurrentProgress = this.mMaxProgress;

        this.OnPropertyChanged(Bind.PropName(() => this.ProgressMax));
      }
    }

    /// <summary>
    /// Get/set current value being displayed in bound progress bar object
    /// </summary>
    public int ProgressValue
    {
      get
      {
        return this.mCurrentProgress;
      }

      set
      {
        if (this.ProgressMax >= value)  // Current progress should be smaller/equal than MaxProgress
          this.mCurrentProgress = value;

        this.OnPropertyChanged(Bind.PropName(() => this.ProgressValue));
      }
    }

    /// <summary>
    /// Determine whether progress bar should be visible or not.
    /// </summary>
    public Visibility IsProgressVisible
    {
      get
      {
        if (this.CanRunProcess == true)
          return Visibility.Collapsed;
        else
          return Visibility.Visible;
      }
    }
    #endregion ProgressBar properties

    /// <summary>
    /// Determine whether the object can run another process or not
    /// (only one background process at a time is supported here).
    /// </summary>
    public bool CanRunProcess
    {
      get
      {
        return this.mCanRunProcess;
      }

      set
      {
        this.mCanRunProcess = value;

        this.OnPropertyChanged(Bind.PropName(() => this.CanRunProcess));
        this.OnPropertyChanged(Bind.PropName(() => this.IsProgressVisible));
      }
    }

    /// <summary>
    /// Determine whether running process can be cancelled or not.
    /// </summary>
    public bool CanCancelRunProcess
    {
      get
      {
        return this.mCanCancelProcess;
      }

      set
      {
        this.mCanCancelProcess = value;

        this.OnPropertyChanged(Bind.PropName(() => this.CanCancelRunProcess));
        this.OnPropertyChanged(Bind.PropName(() => this.IsProgressVisible));
      }
    }

    /// <summary>
    /// Store result of async thread call in dictionary
    /// to be retrieved by caller via string key
    /// </summary>
    public Dictionary<string, object> callResults
    {
      get
      {
        lock (this)
        {
          return this.mResultObjects;
        }
      }

      set
      {
        lock (this)
        {
          this.mResultObjects = value;
        }
      }
    }

    /// <summary>
    /// Determine whether background processing aborted with errors
    /// </summary>
    protected bool AbortedWithErrors
    {
      get { return this.mAbortedWithErrors; }
      set { this.mAbortedWithErrors = value; }
    }

    /// <summary>
    /// Determine whether background processing was cancelled
    /// </summary>
    protected bool AbortedWithCancel
    {
      get { return this.mAbortedWithCancel; }
      set { this.mAbortedWithCancel = value; }
    }

    /// <summary>
    /// Expose cancelToken to derived classes so that they
    /// can cancel the process when it is requested through
    /// this token.
    /// </summary>
    protected CancellationTokenSource CancelTokenSource
    {
      get { return this.mCancelTokenSource; }
      set { this.mCancelTokenSource = value; }
    }

    /// <summary>
    /// Get property to display an exception if any
    /// occured during exection of the background processing
    /// </summary>
    protected Exception InnerException
    {
      get { return this.mInnerException; }
      set { this.mInnerException = value; }
    }
    #endregion Properties

    #region Methodes
    /// <summary>
    /// Create a new instance of a <see cref="ProgressVM"/> CLR object
    /// and bind progress controls (TextBox, ProgressBar, and ListView) necessary
    /// to view current status to properties of that CLR object.
    /// </summary>
    /// <param name="retRunProcess"></param>
    /// <param name="progressBar"></param>
    /// <param name="statusTextBox"></param>
    /// <param name="statusListView"></param>
    /// <param name="lstResults"></param>
    /// <param name="btnStop"></param>
    /// <param name="btnExec"></param>
    /// <returns>CLR object to perform process.</returns>
    public static ProgressVM BindProgressStatusItems(
          ProgressVM retRunProcess,
          ProgressBar progressBar = null,
          TextBox statusTextBox = null,
          ListView statusListView = null,
          ListView lstResults = null,
          Button btnStop = null,
          Button btnExec = null)
    {
      if (btnExec != null)
      {
        Binding bndStop = new Binding(); // Bind enabled property of button to CLR class property
        bndStop.Source = retRunProcess;
        bndStop.Mode = BindingMode.TwoWay;

        bndStop.Path = new PropertyPath(Bind.PropName(() => retRunProcess.CanRunProcess));
        btnExec.SetBinding(Button.IsEnabledProperty, bndStop);
      }

      if (btnStop != null)
      {
        Binding bndStart = new Binding(); // Bind enabled property of button to CLR class property
        bndStart.Mode = BindingMode.TwoWay;
        bndStart.Source = retRunProcess;
        bndStart.Path = new PropertyPath(Bind.PropName(() => retRunProcess.CanCancelRunProcess));
        btnStop.SetBinding(Button.IsEnabledProperty, bndStart);
      }

      // Bind TextBox
      if (statusTextBox != null)
        Bind.BindTextBox(statusTextBox, retRunProcess, Bind.PropName(() => retRunProcess.StatusMessage), BindingMode.OneWay);

      // Bind ListView
      if (lstResults != null)
      {
        Binding bndResult = new Binding();
        bndResult.Source = retRunProcess;
        bndResult.Path = new PropertyPath(Bind.PropName(() => retRunProcess.Message));
        lstResults.SetBinding(DataGrid.ItemsSourceProperty, bndResult);
      }

      if (statusListView != null)
      {
        Binding bndResult = new Binding();
        bndResult.Source = retRunProcess;
        bndResult.Path = new PropertyPath(Bind.PropName(() => retRunProcess.Message));
        statusListView.SetBinding(DataGrid.ItemsSourceProperty, bndResult);
      }

      // Bind ProgressBar
      if (progressBar != null)
        Bind.BindProgressBar(progressBar, retRunProcess,
                             Bind.PropName(() => retRunProcess.ProgressMin),
                             Bind.PropName(() => retRunProcess.ProgressMax),
                             Bind.PropName(() => retRunProcess.ProgressValue),
                             Bind.PropName(() => retRunProcess.IsProgressVisible));

      return retRunProcess;
    }

    /// <summary>
    /// Switch progress indicators for long running processes in GUI ON or OFF
    /// </summary>
    /// <param name="isVisible"></param>
    /// <param name="bError"></param>
    public void SetProgressVisibility(bool isVisible, bool bError = false)
    {
      if (isVisible == false)
      {
        if (bError == true)        // Stop busy indication in all relevant controls
          this.StatusMessage = this.StatusMessage + "(Code: " + this.StatusMessage + ")";
        else
          this.StatusMessage = "Ready";
      }
      else
      {
        // Start busy indication in all relevant controls
        this.StatusMessage = "Processing...";
      }
    }

    /// <summary>
    /// Main program entry point for running a background task while
    /// reporting progress and letting a user cancel as necessary.
    /// </summary>
    public bool RunProcess(bool bExecAsynchron,
                           Dictionary<string, object> callParameters,
                           Func<Dictionary<string, object>, int> execFunc)
    {
      // Remember the context of the calling thread
      this.SaveThreadContext(bExecAsynchron);

      string sParameter = string.Empty;
      string sMsg = string.Empty;

      try
      {
        this.ResetMessages();

        this.CancelTokenSource = new CancellationTokenSource();
        CancellationToken cancelToken = this.CancelTokenSource.Token;

        string sTaskError = string.Empty;

        Task taskToProcess = null;
        this.ResultCode = ProgressVM.OkNoError;
        taskToProcess = Task.Factory.StartNew<int>((stateObj) =>
        {
          try
          {
            this.AbortedWithErrors = this.AbortedWithCancel = false;
            this.Message = new ObservableCollection<string>();
            this.OnPropertyChanged(Bind.PropName(() => this.Message));

            this.ProgressMax = 4;   // Let progress show that somethings going on
            this.ProgressValue = 1;

            cancelToken.ThrowIfCancellationRequested();

            // Execute processing function and not result (if any known is available)
            if ((this.ResultCode = execFunc(callParameters)) == ProgressVM.Cancelled)       
              this.AbortedWithCancel = true;
            else
              if (this.ResultCode == ProgressVM.Failed)
                this.AbortedWithErrors = true;
          }
          catch (OperationCanceledException exp)
          {
            string sStatus = exp.Message;        // Print: "The Operation was canceled." ...
            this.AddMessage(string.Format("User cancelled {0}.", this.ProcessName));
            this.ProgressValue = 0;
            this.StatusMessage = sStatus;
            this.AbortedWithCancel = true;
          }
          catch (Exception Exp)
          {
            this.AbortedWithErrors = true;
            this.InnerException = Exp;
            this.AddMessage(string.Format("Failed to execute {0}.", this.ProcessName));
            this.ResultCode = ProgressVM.Failed;
          }
          finally
          {
            this.CanRunProcess = true;           // Ensure correct state of bound GUI elements
            this.CanCancelRunProcess = false;
          }

          return this.ResultCode;           // End of async task with result code
        },
        cancelToken).ContinueWith(ant =>
        {
          try
          {
            this.ProgressMin = 0;
            if (sTaskError.Length > 0)
              this.StatusMessage = sTaskError;

            this.ReportProcesingResultEvent(bExecAsynchron);
          }
          catch (AggregateException aggExp)
          {
            this.AddMessage("Error: " + PrintException(taskToProcess, aggExp, "Copy"));
          }
        });

        if (bExecAsynchron == false)          // Execute 'synchronously' via wait/block method
          taskToProcess.Wait();
      }
      catch (Exception exp)
      {
        this.AddMessage(string.Format("Failed to complete {0} reason: '" + Environment.NewLine +
                                     "{1}", this.ProcessName, exp.ToString()));

        this.ResultCode = ProgressVM.Failed;
        return false;                     // Task initialization was unsuccessful and is NOT on its way
      }

      this.ResultCode = ProgressVM.OkNoError;
      return true;                   // Task initialization was successful and is on its way
    }

    /// <summary>
    /// Cancel a process if it is currently underway.
    /// </summary>
    public void Cancel()
    {
      if (this.mCancelTokenSource != null)
      {
        this.mCancelTokenSource.Cancel();

        // Tell bound controls to disable themselves so cancelling twice is next to impossible
        this.CanCancelRunProcess = false;
      }
    }

    /// <summary>
    /// Analyze AggregateException (typically returned from Task class) and return human-readable
    /// string for display in GUI.
    /// </summary>
    /// <param name="task"></param>
    /// <param name="agg"></param>
    /// <param name="taskName"></param>
    /// <returns></returns>
    protected string PrintException(Task task, AggregateException agg, string taskName)
    {
      string sResult = string.Empty;

      foreach (Exception ex in agg.InnerExceptions)
      {
        sResult += string.Format("{0} Caught exception '{1}'", taskName, ex.Message) + Environment.NewLine;
      }

      sResult += string.Format("{0} cancelled? {1}", taskName, task.IsCanceled) + Environment.NewLine;

      return sResult;
    }

    /// <summary>
    /// Save the threading context of a calling thread to enable event completion handling
    /// in original context when async task has finished (WPF, Winforms and co require this)
    /// </summary>
    /// <param name="bAsnc"></param>
    protected void SaveThreadContext(bool bAsnc)
    {
      // non-Asnyc threads are simply blocked until they finish
      // hence completed event is not required to fire
      if (bAsnc == false) return;

      if (this.mRequestingContext != null)
        throw new InvalidOperationException("This component can handle only 1 processing request at a time");

      this.mRequestingContext = (DispatcherSynchronizationContext)DispatcherSynchronizationContext.Current;
    }

    /// <summary>
    /// Report a result to the attached eventhalders (if any) on whether execution succeded or not.
    /// </summary>
    protected void ReportProcesingResultEvent(bool bAsnc)
    {
      // non-Asnyc threads are simply blocked until they finish
      // hence completed event is not required to fire
      if (bAsnc == false) return;

      SendOrPostCallback callback = new SendOrPostCallback(this.ReportTaskCompletedEvent);
      this.mRequestingContext.Post(callback, null);
      this.mRequestingContext = null;
    }

    /// <summary>
    /// Empty all existing messages and construct a new tool messages collection
    /// (this method is protected because setting this should not be allowed by
    /// the outside world [since asynchrone task reports to this collection])
    /// </summary>
    protected void ResetMessages()
    {
      this.mMessage = new ObservableCollection<string>();
      this.OnPropertyChanged(Bind.PropName(() => this.Message));
    }

    /// <summary>
    /// Add one more message to the list of messages to output for this processing
    /// </summary>
    /// <param name="sMsg"></param>
    protected bool AddMessage(string sMsg)
    {
      lock (this)
      {
        try
        {
          if (this.mMessage == null)
            this.Message = new ObservableCollection<string>();

          // Editing the collection directly caused the Collection view to raise an exception
          // This type of CollectionView does not support changes to its SourceCollection from a thread different from the Dispatcher thread.
          // Bug, solution Source: http://stackoverflow.com/questions/2137769/wpf-where-do-i-get-a-threadsafe-collectionview
          System.Windows.Application.Current.Dispatcher.Invoke(
              System.Windows.Threading.DispatcherPriority.Normal,
              (Action)delegate
              {
                this.Message.Add(sMsg);
              });

          this.OnPropertyChanged(Bind.PropName(() => this.Message));
        }
        catch
        {
          return false;
        }

        return true;
      }
    }

    /// <summary>
    /// Report the asynchronous task as having completed
    /// </summary>
    /// <param name="e"></param>
    private void ReportTaskCompletedEvent(object e)
    {
      if (this.resultEvent != null)
      {
        ProgressResult result = null;

        if (this.mAbortedWithErrors == false && this.mAbortedWithCancel == false)
          result = new ProgressResult("Execution succeeded", false, false, this.mResultObjects);
        else
          result = new ProgressResult("Execution was not succesfull", this.mAbortedWithErrors,
                                                      this.mAbortedWithCancel, this.mResultObjects, this.mInnerException);

        result.ResultCode = this.ResultCode;
        this.resultEvent(this, result);
      }
    }
    #endregion Methodes

    #region Nested Classes
    /// <summary>
    /// Stores information about the result of a processing run.
    /// If an error occurs, Error is set to true and an exception
    /// may be stored in the <see cref="InnerException"/> property.
    /// </summary>
    public class ProgressResult : EventArgs
    {
      #region Fields
      private bool mError;
      private bool mCancel;
      private Exception mInnerException;
      private string mMessage;
      private Dictionary<string, object> mObjColl = null;
      #endregion Fields

      #region Constructors
      /// <summary>
      /// Convinience constructor to produce simple message for communicating when
      /// processing was abborted incompletely (bCancel can be set to true or bError
      /// can be set to true).
      /// </summary>
      /// <param name="sMessage"></param>
      /// <param name="bError"></param>
      /// <param name="bCancel"></param>
      /// <param name="objColl"></param>
      /// <param name="innerException"></param>
      public ProgressResult(string sMessage,
                            bool bError,
                            bool bCancel,
                            Dictionary<string, object> objColl = null,
                            Exception innerException = null)
      {
        this.mMessage = sMessage;
        this.mError = bError;
        this.mCancel = bCancel;
        this.mInnerException = (innerException == null ? null : innerException);
        this.mObjColl = (objColl == null ? null : new Dictionary<string, object>(objColl));
      }

      /// <summary>
      /// Convinience constructor to produce simple message at the end of a process run
      /// (Cancel not clicked and no error to be reported).
      /// </summary>
      /// <param name="message"></param>
      public ProgressResult(string message)
      {
        this.mMessage = message;
        this.mError = false;
        this.mCancel = false;
        this.mInnerException = null;
      }
      #endregion Constructors

      #region Properties
      /// <summary>
      /// Get/set property to store result code for background processing
      /// </summary>
      public int ResultCode { get; set; }

      /// <summary>
      /// Determine whether the background processing
      /// was aborted with errors or not.
      /// </summary>
      public bool Error
      {
        get { return this.mError; }
      }

      /// <summary>
      /// Determine whether the background processing
      /// was cancelled by the user or not.
      /// </summary>
      public bool Cancel
      {
        get { return this.mCancel; }
      }

      /// <summary>
      /// Get property to display an InnerException (if any)
      /// if the process aborted with errors
      /// </summary>
      public Exception InnerException
      {
        get { return this.mInnerException; }
      }

      /// <summary>
      /// Store an error message or any other message (if any) associated
      /// to the result of the background processing.
      /// </summary>
      public string Message
      {
        get { return this.mMessage; }
      }

      /// <summary>
      /// Property to expose a dictionary of result objects
      /// which represents the result of the background processing.
      /// </summary>
      public Dictionary<string, object> ResultObjects
      {
        get
        {
          return (this.mObjColl == null ? new Dictionary<string, object>() :
                                          new Dictionary<string, object>(this.mObjColl));
        }
      }
      #endregion Properties
    }
    #endregion Nested Classes
  }
}

﻿namespace Progress
{
  using System;
  using System.Collections.Generic;
  using System.Linq.Expressions;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Data;

  /// <summary>
  /// Simple helper class containing static methods for binding/unbinding
  /// GUI controls to CLR properties at run time.
  /// </summary>
  public class Bind
  {
    /// <summary>
    /// Resolve a property name of a class via LINQ and return the name as string
    ///
    /// Sample call: this.OnPropertyChanged(() => this.IsSelected);
    /// where 'this' is derived from <seealso cref="BaseVM"/>
    /// and IsSelected is a property.
    /// </summary>
    /// <typeparam name="TProperty"></typeparam>
    /// <param name="property"></param>
    /// <returns></returns>
    public static string PropName<TProperty>(Expression<Func<TProperty>> property)
    {
      var lambda = (LambdaExpression)property;
      MemberExpression memberExpression;

      if (lambda.Body is UnaryExpression)
      {
        var unaryExpression = (UnaryExpression)lambda.Body;
        memberExpression = (MemberExpression)unaryExpression.Operand;
      }
      else
        memberExpression = (MemberExpression)lambda.Body;

      return memberExpression.Member.Name;
    }

    #region bind unbind ProgressBar
    /// <summary>
    /// Bind a ProgressBar control to the properties of CLR object.
    /// 
    /// Code can throw exception: 'PART_Track' name cannot be found in the name scope of 'System.Windows.Controls.ControlTemplate'.
    /// Workaround solution is to enforce visiblity by setting Visibility="Visible" in XAML,
    /// because the SetBinding function below will throw an exception if control is not Visible.
    /// </summary>
    /// <param name="progressBar">ProgressBar object visible in GUI (usually defined in XAML)</param>
    /// <param name="source">Reference to CLR object instance</param>
    /// <param name="minPropertyName">Name of minimum property in CLR object</param>
    /// <param name="maxPropertyName">Name of maximum property in CLR object</param>
    /// <param name="valuePropertyName">Name of current value indicator property in in CLR object</param>
    /// <param name="visibilityPropertyName"></param>
    public static void BindProgressBar(ProgressBar progressBar,
                                       object source,
                                       string minPropertyName = "",
                                       string maxPropertyName = "",
                                       string valuePropertyName = "",
                                       string visibilityPropertyName = "")
    {
      if (valuePropertyName.Length > 0)
      {
        Binding bndValue = new Binding();
        bndValue.Source = source;
        bndValue.Path = new PropertyPath(valuePropertyName);
        progressBar.SetBinding(ProgressBar.ValueProperty, bndValue);
      }

      if (maxPropertyName.Length > 0)
      {
        Binding bndMaxValue = new Binding();
        bndMaxValue.Source = source;
        bndMaxValue.Path = new PropertyPath(maxPropertyName);
        progressBar.SetBinding(ProgressBar.MaximumProperty, bndMaxValue);
      }

      if (minPropertyName.Length > 0)
      {
        Binding bndMaxValue = new Binding();
        bndMaxValue.Source = source;
        bndMaxValue.Path = new PropertyPath(minPropertyName);
        progressBar.SetBinding(ProgressBar.MinimumProperty, bndMaxValue);
      }

      if (visibilityPropertyName.Length > 0)
      {
        Binding bndProgress = new Binding();
        ////bndProgress.Mode = BindingMode.OneWay;
        bndProgress.Source = source;
        bndProgress.Path = new PropertyPath(visibilityPropertyName);
        progressBar.SetBinding(ProgressBar.VisibilityProperty, bndProgress);
      }
    }

    /// <summary>
    /// Remove the ProgressBar binding (if any) from
    /// MinimumProperty, MaximumProperty, ValueProperty, and VisibilityProperty
    /// </summary>
    /// <param name="progressBar"></param>
    public static void UnbindProgressBar(ProgressBar progressBar)
    {
      if (BindingOperations.IsDataBound(progressBar, ProgressBar.MinimumProperty))
        BindingOperations.ClearBinding(progressBar, ProgressBar.MinimumProperty);

      if (BindingOperations.IsDataBound(progressBar, ProgressBar.MaximumProperty))
        BindingOperations.ClearBinding(progressBar, ProgressBar.MaximumProperty);

      if (BindingOperations.IsDataBound(progressBar, ProgressBar.ValueProperty))
        BindingOperations.ClearBinding(progressBar, ProgressBar.ValueProperty);

      if (BindingOperations.IsDataBound(progressBar, ProgressBar.VisibilityProperty))
        BindingOperations.ClearBinding(progressBar, ProgressBar.VisibilityProperty);
    }
    #endregion bind unbind ProgressBar

    #region bind unbind textbox
    /// <summary>
    /// Bind the Text property of a TextBox object to the
    /// <paramref name="sourcePropertyName"/> property in
    /// the <paramref name="source"/> (CLR) object.
    /// </summary>
    /// <param name="textBox"></param>
    /// <param name="source"></param>
    /// <param name="sourcePropertyName"></param>
    /// <param name="bindingMode"></param>
    public static void BindTextBox(TextBox textBox,
                                     object source,
                                     string sourcePropertyName,
                                     BindingMode bindingMode = BindingMode.TwoWay)
    {
      Binding myBinding = new Binding();                        // Create the Binding
      myBinding.Source = source;                               // Set the Source
      myBinding.Path = new PropertyPath(sourcePropertyName);  // Set the Path
      myBinding.Mode = bindingMode;

      // Connect the Source and the Target.
      textBox.SetBinding(TextBox.TextProperty, myBinding);
    }

    /// <summary>
    /// Bind the Text property of a TextBox object to the
    /// sourcePropertyName property in
    /// the <paramref name="source"/> (CLR) object.
    /// 
    /// Call method with Lamda expression BindTextBox(() => this.sourcePropertyName, ...);
    /// </summary>
    /// <typeparam name="TProperty"></typeparam>
    /// <param name="property"></param>
    /// <param name="textBox"></param>
    /// <param name="source"></param>
    /// <param name="bindingMode"></param>
    public static void BindTextBox<TProperty>(Expression<Func<TProperty>> property,
                                              TextBox textBox,
                                              object source,
                                              BindingMode bindingMode = BindingMode.TwoWay)
    {
      var lambda = (LambdaExpression)property;
      MemberExpression memberExpression;

      if (lambda.Body is UnaryExpression)
      {
        var unaryExpression = (UnaryExpression)lambda.Body;
        memberExpression = (MemberExpression)unaryExpression.Operand;
      }
      else
        memberExpression = (MemberExpression)lambda.Body;

      Bind.BindTextBox(textBox, source, memberExpression.Member.Name, bindingMode);
    }

    /// <summary>
    /// Remove binding (if any) from TextProperty of TextBox
    /// </summary>
    /// <param name="textBox"></param>
    public static void UnbindTextBox(TextBox textBox)
    {
      if (BindingOperations.IsDataBound(textBox, TextBox.TextProperty))
        BindingOperations.ClearBinding(textBox, TextBox.TextProperty);
    }
    #endregion bind unbind textbox

    #region bind unbind checkbox
    /// <summary>
    /// Bind the IsChecked property of a CheckBox object to the
    /// <paramref name="sourcePropertyName"/> property in
    /// the <paramref name="source"/> (CLR) object.
    /// </summary>
    /// <param name="checkBox"></param>
    /// <param name="source"></param>
    /// <param name="sourcePropertyName"></param>
    public static void BindCheckBox(CheckBox checkBox,
                                     object source,
                                     string sourcePropertyName)
    {
      Binding myBinding = new Binding();                              // Create the Binding
      myBinding.Source = source;                                     // Set the Source <- server
      myBinding.Path = new PropertyPath(sourcePropertyName);        // Set the Path <- "Enabled"
      checkBox.SetBinding(CheckBox.IsCheckedProperty, myBinding);  // Connect the Source and the Target. <- this.SvrEnabled
    }

    /// <summary>
    /// Bind the IsChecked property of a CheckBox object to the
    /// sourcePropertyName property in
    /// the <paramref name="source"/> (CLR) object.
    /// 
    /// Call method with Lamda expression BindTextBox(() => this.sourcePropertyName, ...);
    /// </summary>
    /// <typeparam name="TProperty"></typeparam>
    /// <param name="property"></param>
    /// <param name="checkBox"></param>
    /// <param name="source"></param>
    public static void BindCheckBox<TProperty>(Expression<Func<TProperty>> property,
                                               CheckBox checkBox,
                                               object source)
    {
      var lambda = (LambdaExpression)property;
      MemberExpression memberExpression;

      if (lambda.Body is UnaryExpression)
      {
        var unaryExpression = (UnaryExpression)lambda.Body;
        memberExpression = (MemberExpression)unaryExpression.Operand;
      }
      else
        memberExpression = (MemberExpression)lambda.Body;

      Bind.BindCheckBox(checkBox, source, memberExpression.Member.Name);
    }

    /// <summary>
    /// Remove IsChecked property binding (if any) from CheckBox object.
    /// </summary>
    /// <param name="checkBox"></param>
    public static void UnbindCheckBox(CheckBox checkBox)
    {
      if (BindingOperations.IsDataBound(checkBox, CheckBox.IsCheckedProperty))
        BindingOperations.ClearBinding(checkBox, CheckBox.IsCheckedProperty);
    }
    #endregion bind unbind checkbox
  }
}

﻿
FileSize package contains functions to compute different sizes, such as, 1024 Mb
into 1 Gb or bytes... etc

There are also Convert and MultiValueConverters for usage in XAML.
   
See FileSize_Converter_Test project for more details.

BugFix:
Entering floating point numbers for the memory size requires binding to a text field and
computing actual number of bytes via seperate SelectedMemSize property in ProgramOptionsVM.
﻿namespace LabelWithContextMenu.Unit.Distance.Metric
{
  using System;

  public sealed class DistanceMillimeter
  {
    private double mValue = 0;

    #region constructor
    public DistanceMillimeter(double value)
    {
      this.mValue = value;
    }

    private DistanceMillimeter()
    {
      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      DistanceMillimeter d = new DistanceMillimeter(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.DisMetricKilometer:
          return this.mValue * (1 / 1000000.0);
                               
        case Itemkey.DisMetricMeter:
          return this.mValue * (1 / 1000.0);

        case Itemkey.DisMetricCentimeter:
          return this.mValue * (1 / 10.0);

        case Itemkey.DisMetricMillimeter:
          return this.mValue;

        case Itemkey.DisMetricNanometer:
          return this.mValue * 1000000.0;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

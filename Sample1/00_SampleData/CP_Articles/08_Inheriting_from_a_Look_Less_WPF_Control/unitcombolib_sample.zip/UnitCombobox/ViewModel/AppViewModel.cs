﻿namespace UnitCombobox.ViewModel
{
  using System.Collections.ObjectModel;
  using UnitComboLib.Unit;
  using UnitComboLib.Unit.Temperature;
  using UnitComboLib.ViewModel;

  public class AppViewModel : BaseViewModel
  {
    #region constructor
    public AppViewModel()
    {
      this.SizeUnitLabel = new UnitViewModel(this.GenerateScreenUnitList(), new ConverterTemperature(),
                                             0,     // Default Unit 100 Degree Celsius
                                             100   // Default Value
                                             );
    }
    #endregion constructor

    #region properties
    public UnitViewModel SizeUnitLabel { get; private set; }
    #endregion properties

    #region methods
    private ObservableCollection<ListItem> GenerateScreenUnitList()
    {
      ObservableCollection<ListItem> unitList = new ObservableCollection<ListItem>();

      var celsiusDefaults = new ObservableCollection<string>()    {      "0",     "25",     "50",    "100",    "125",    "250",    "200" };
      var fahrenheitDefaults = new ObservableCollection<string>() {     "32",     "77",    "122",    "212",    "257",    "482",    "392" };
      var kelvinDefaults = new ObservableCollection<string>()     { "273,15", "298,15", "323,15", "373,15", "398,15", "523,15", "473,15" };

      unitList.Add(new ListItem(Itemkey.TemperaturCelsius, "Degree Celsius", "°C", celsiusDefaults));
      unitList.Add(new ListItem(Itemkey.TemperaturDegreeFahrenheit, "Degree Fahrenheit", "F", fahrenheitDefaults));
      unitList.Add(new ListItem(Itemkey.TemperaturKelvin, "Kelvin", "K", kelvinDefaults));

      return unitList;
    }
    #endregion methods
  }
}

﻿namespace FileSize_Converter_Test.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Collections.ObjectModel;
  using System.ComponentModel;
  using System.Linq;
  using System.Windows;

  using FSControls.FileSize;

  /// <summary>
  /// A UI-friendly wrapper around a Program options (<seealso cref="DBRestore.Model.Params"/>) object.
  /// </summary>
  internal class ProgramOptionsVM : BaseViewModel
  {
    #region Fields
    private readonly Dictionary<MemUnit, UIList> mMemUnits;
    private MemUnit mSelectedMemUnit;
    private double mSelectedMemSize;
    #endregion Fields

    #region Constructors
    /// <summary>
    /// Class constructor
    /// </summary>
    /// <param name="programParams"></param>
    public ProgramOptionsVM()
    {
      // Initialize list of compression levels and select a default value
      this.mMemUnits = UIList.GetDicOfCompressionLevels();
      this.mSelectedMemUnit = MemUnit.Mb;
      this.mSelectedMemSize = 300;
    }

    /// <summary>
    /// Copy constructor
    /// </summary>
    /// <param name="inProgOpts"></param>
    public ProgramOptionsVM(ProgramOptionsVM inProgOpts)
    {
      this.mMemUnits = new Dictionary<MemUnit, UIList>(inProgOpts.mMemUnits);

      this.mSelectedMemUnit = inProgOpts.mSelectedMemUnit;
      this.mSelectedMemSize = inProgOpts.mSelectedMemSize;
    }
    #endregion Constructors

    #region Properties
    /// <summary>
    /// List of supported memory size units (bytes, Kb, Mb ...)
    /// </summary>
    public Dictionary<MemUnit, UIList> MemUnits
    {
      get { return this.mMemUnits; }
    }

    /// <summary>
    /// List of supported memory size unit (bytes, Kb, Mb ...)
    /// </summary>
    public MemUnit SelectedMemUnit
    {
      get
      {
        return this.mSelectedMemUnit;
      }

      set
      {
        this.mSelectedMemUnit = value;
        this.OnPropertyChanged("SelectedMemUnit");
      }
    }

    /// <summary>
    /// Selected size of memory in the unit input by the user.
    /// Use a conversion to number of bytes via the <seealso cref="FileSizeContext.ConvertUnparsedSizeToBytesInt"/>
    /// method if your code needs to work with the actual data.
    /// </summary>
    public string SelectedMemSize
    {
      get
      {
        return this.mSelectedMemSize.ToString();
      }

      set
      {
        string sInput = string.Format("{0} {1}", value, this.mSelectedMemUnit);
        ulong numberOfBytes;
        string[] sComponents;

        if (FileSizeContext.ConvertUnparsedSizeToBytesInt(sInput, out numberOfBytes, out sComponents) == true)
        {
          double dResult;
          double.TryParse(value, out dResult);

          this.mSelectedMemSize = dResult;
        }

        this.OnPropertyChanged(typeof(ProgramOptionsVM).GetProperty("SelectedMemSize").Name);
        this.OnPropertyChanged(typeof(ProgramOptionsVM).GetProperty("SelectedMemUnit").Name);
      }
    }

    /// <summary>
    /// Minimum allowed value to be entered is 100Mb
    /// </summary>
    public ulong SelectedMemMin
    {
      get
      {
        return 104857600;
      }
    }

    /// <summary>
    /// Maximum allowed value to be entered is 4Gb
    /// </summary>
    public ulong SelectedMemMax
    {
      get
      {
        return 4294967296;
      }
    }

    /// <summary>
    /// Get the selected memory size in number of bytes for processing in program.
    /// </summary>
    public ulong SelectedMemSizeNumberOfBytes
    {
      get
      {
        ulong numberOfBytes;
        string[] inputComponents;
        string stringInput = string.Format("{0} {1}", this.SelectedMemSize, this.SelectedMemUnit);

        if(FileSizeContext.ConvertUnparsedSizeToBytesInt(stringInput, out numberOfBytes, out inputComponents) == true)
        {
          return numberOfBytes;
        }

        return 0; // Error: This should never happen in practice, if converters make sure that users cannot enter invalid values
      }
    }
    #endregion Properties
  }
}

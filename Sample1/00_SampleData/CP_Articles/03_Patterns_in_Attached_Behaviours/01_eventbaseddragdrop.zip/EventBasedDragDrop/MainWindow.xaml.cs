﻿namespace EventBasedDragDrop
{
  using System.Windows;

  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    /// <summary>
    /// This method is fired whenever a file drop event occurs
    /// </summary>
    private void DropEventHandler(object sender, DragEventArgs e)
    {
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
      {
        string[] droppedFilePaths =
        e.Data.GetData(DataFormats.FileDrop, true) as string[];

        foreach (string droppedFilePath in droppedFilePaths)
        {
          MessageBox.Show(string.Format("Opening file '{0}'", droppedFilePath), "Debug Info", MessageBoxButton.OK);
        }
      }
    }
  }
}

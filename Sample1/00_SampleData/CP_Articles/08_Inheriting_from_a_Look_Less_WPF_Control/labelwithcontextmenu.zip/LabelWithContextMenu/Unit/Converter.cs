﻿namespace LabelWithContextMenu.Unit
{
  /// <summary>
  /// Enumeration keys for each unit
  /// </summary>
  public enum Itemkey
  {
    DisMetricKilometer = 0,   // Units of metric length
    DisMetricMeter = 1,
    DisMetricCentimeter = 2,
    DisMetricMillimeter = 3,
    DisMetricNanometer = 4,

    ScreenFontPoints = 5,    // Units of computer screen dimensions
    ScreenPercent = 6
  }

  public abstract class Converter
  {
    public abstract double Convert(Itemkey inputUnit, double inputValue, Itemkey outputUnit);
  }
}

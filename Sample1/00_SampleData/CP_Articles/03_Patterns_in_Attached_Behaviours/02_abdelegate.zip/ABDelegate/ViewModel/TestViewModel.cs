﻿namespace ABDelegate.ViewModel
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;
using System.Windows.Input;
  using System.Windows;

  class TestViewModel : ViewModelBase
  {
    public TestViewModel()
    {
      this.LoadFileCommand = new RelayCommand
      (
        (p) =>
        {
          string droppedFilePath = p as string;

          if (droppedFilePath == null)
            return;

          MessageBox.Show(string.Format("Opening file '{0}'", droppedFilePath), "Debug Info", MessageBoxButton.OK);
        }
      );
    }

    /// <summary>
    /// Command that write the event name that executed the command
    /// </summary>
    public ICommand LoadFileCommand { get; private set; }
  }
}

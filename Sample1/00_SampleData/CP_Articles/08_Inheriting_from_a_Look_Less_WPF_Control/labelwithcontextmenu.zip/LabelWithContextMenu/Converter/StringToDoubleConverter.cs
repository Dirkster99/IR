﻿namespace LabelWithContextMenu.Converter
{
  using System;
  using System.Globalization;
  using System.Windows.Data;
  using System.Windows.Markup;

  /// <summary>
  /// Converts a string into a double value (without digits) and back.
  /// </summary>
  [ValueConversion(typeof(string), typeof(double))]
  public class StringToDoubleConverter : MarkupExtension, IValueConverter
  {
    public const double FallBackDefaultValue = 1.0;
    public const string DefaultFormat = "{0}"; // 2 digits "{0:0.00}"
    private static StringToDoubleConverter converter;

    /// <summary>
    /// Standard constructor
    /// </summary>
    public StringToDoubleConverter()
    {
    }

    /// <summary>
    /// When implemented in a derived class, returns an object that is provided
    /// as the value of the target property for this markup extension.
    /// 
    /// When a XAML processor processes a type node and member value that is a markup extension,
    /// it invokes the ProvideValue method of that markup extension and writes the result into the
    /// object graph or serialization stream. The XAML object writer passes service context to each
    /// such implementation through the serviceProvider parameter.
    /// </summary>
    /// <param name="serviceProvider"></param>
    /// <returns></returns>
    public override object ProvideValue(IServiceProvider serviceProvider)
    {
      if (converter == null)
        converter = new StringToDoubleConverter();

      return converter;
    }

    #region IValueConverter Members

    /// <summary>
    /// Convert from double to string
    /// </summary>
    /// <param name="value"></param>
    /// <param name="targetType"></param>
    /// <param name="parameter"></param>
    /// <param name="culture"></param>
    /// <returns></returns>
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      var fsize = value as double?;

      if (fsize != null)
        return string.Format(DefaultFormat, value);

      return string.Format(DefaultFormat, FallBackDefaultValue);
    }

    /// <summary>
    /// Convert from string to double
    /// </summary>
    /// <param name="value"></param>
    /// <param name="targetType"></param>
    /// <param name="parameter"></param>
    /// <param name="culture"></param>
    /// <returns></returns>
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
      if (value == null)
        return Binding.DoNothing;

      var str = value as string;
      double doubleValue;

      if (double.TryParse(str, out doubleValue))
        return doubleValue;

      return FallBackDefaultValue;
    }

    #endregion IValueConverter Members
  }
}

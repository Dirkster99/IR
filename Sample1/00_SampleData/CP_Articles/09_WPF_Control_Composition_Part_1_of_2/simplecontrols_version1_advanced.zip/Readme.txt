
StyleCop
--------

I use StyleCop in my projects to make the code readable in a uniform way.
So, if you should get an error when compiling the project, you can either
download and install StyleCop, or edit/remove the corresponding entries in
each .csproj file:

<Import Project="$(ProgramFiles)\MSBuild\StyleCop\v4.7\StyleCop.Targets" />


Simple Controls (Version 1)
---------------------------

This version of the Simple Controls project contains a WPF control collection of:

- A Combobox with label
- A Combobox and Textbox with label
- A Watermark textbox with label

Introduction
------------

The project shows how the above components can be
arranged with label without having to declare each label
each time the control is needed.

Just declaring the control and setting the dependency
property in XAML is all that is needed to arrive at a simple
standard layout.


RESTRICTION
-----------
Controls in this project cannot be themed. Please refer to Version 2 if you are
looking for skinable WPF control samples.

See

http://www.codeproject.com/Articles/332539/WPFControlCompositionPart1of2
http://www.codeproject.com/Articles/332541/WPFControlCompositionPart2of2

for more details.

﻿namespace FileListView.Views
{
  using System.Windows.Controls;

  /// <summary>
  /// Interaction logic for FileListView.xaml
  /// </summary>
  public partial class FListView : ListView
  {
    #region constructor
    /// <summary>
    /// Class constructor
    /// </summary>
    public FListView()
    {
      this.InitializeComponent();
    }
    #endregion constructor
  }
}

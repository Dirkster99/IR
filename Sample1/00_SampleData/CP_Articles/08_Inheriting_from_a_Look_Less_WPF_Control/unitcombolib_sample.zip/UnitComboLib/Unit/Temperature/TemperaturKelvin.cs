﻿namespace UnitComboLib.Unit.Temperature
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;

  public class TemperaturKelvin
  {
    private double mValue = 0;

    #region constructor
    public TemperaturKelvin(double value)
    {
      this.mValue = value;
    }

    private TemperaturKelvin()
    {      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      TemperaturKelvin d = new TemperaturKelvin(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.TemperaturCelsius:
          return this.mValue - 273.15;

        case Itemkey.TemperaturDegreeFahrenheit:
          return this.mValue * 1.8 - 459.67;

        case Itemkey.TemperaturKelvin:
          return this.mValue;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

﻿namespace ABCommand
{
  using System.Windows.Input;

  class AppCommand
  {
    private static RoutedUICommand loadFile;

    static AppCommand()
    {
      InputGestureCollection inputs = null;

      // Initialize the exit command
      inputs = new InputGestureCollection();
      AppCommand.loadFile = new RoutedUICommand("Load a File", "LoadFile", typeof(AppCommand));
    }

    /// <summary>
    /// Static property of the correspondong <seealso cref="System.Windows.Input.RoutedUICommand"/>
    /// </summary>
    public static RoutedUICommand LoadFile
    {
      get { return AppCommand.loadFile; }
    }
  }
}

﻿namespace ABDelegate
{
  using System.Windows;
  using ABDelegate.ViewModel;

  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
    private void Application_Startup(object sender, StartupEventArgs e)
    {
      // Construct ViewModel and MainWindow
      TestViewModel tVM = new TestViewModel();
      View.MainWindow w = new View.MainWindow();

      // Attach ViewModel to DataContext of ViewModel
      w.DataContext = tVM;

      // SHOW ME DA WINDOW!
      w.Show();
    }
  }
}

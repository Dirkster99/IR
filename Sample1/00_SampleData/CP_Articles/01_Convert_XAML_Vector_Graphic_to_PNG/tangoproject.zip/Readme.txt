
http://en.wikipedia.org/wiki/Tango_Desktop_Project


http://tango.freedesktop.org/

Terms Of Use

The Tango base icon theme is released to the Public Domain.
The palette is in public domain. Developers, feel free to ship it along with your application.
The  icon naming utilities are licensed under the GPL.

Though the tango-icon-theme package is released to the Public Domain, we ask that you still
please attribute the Tango Desktop Project, for all the hard work  we've done. Thanks. 
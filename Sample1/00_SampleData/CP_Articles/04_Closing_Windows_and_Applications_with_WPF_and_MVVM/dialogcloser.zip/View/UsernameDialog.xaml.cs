﻿namespace DialogCloser.View
{
  using System.Windows;
  using System.Windows.Input;

  /// <summary>
  /// Interaction logic for TestDialog.xaml
  /// </summary>
  public partial class UsernameDialog : Window
  {
    public UsernameDialog()
    {
      this.InitializeComponent();
    }
  }
}

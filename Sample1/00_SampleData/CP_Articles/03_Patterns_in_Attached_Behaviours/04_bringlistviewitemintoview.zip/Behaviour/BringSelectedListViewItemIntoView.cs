﻿namespace BringListViewItemIntoView.Behaviour
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Text;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Input;

  /// <summary>
  /// ListView Behavior class
  /// This class implements an attached behaviour to scroll to an
  /// item that can programatically be selected via ViewModel binding
  /// 
  /// Sources:
  /// http://stackoverflow.com/questions/3317194/mvvm-how-to-make-a-list-view-auto-scroll-to-a-new-item-in-a-list-view
  /// http://stackoverflow.com/questions/211971/scroll-wpf-listview-to-specific-line
  /// </summary>
  public static class BringSelectedListViewItemIntoView
  {
    /// <summary>
    /// Determins if the ListBoxItem is bought into view when enabled
    /// </summary>
    public static readonly DependencyProperty IsBroughtIntoViewWhenSelectedProperty =
        DependencyProperty.RegisterAttached(
        "IsBroughtIntoViewWhenSelected",
        typeof(bool),
        typeof(BringSelectedListViewItemIntoView),
        new UIPropertyMetadata(false, OnIsBroughtIntoViewWhenSelectedChanged));

    /// <summary>
    /// Gets the IsBroughtIntoViewWhenSelected value
    /// </summary>
    /// <param name="listBoxItem"></param>
    /// <returns></returns>
    public static bool GetIsBroughtIntoViewWhenSelected(ListView listBoxItem)
    {
      return (bool)listBoxItem.GetValue(IsBroughtIntoViewWhenSelectedProperty);
    }

    /// <summary>
    /// Sets the IsBroughtIntoViewWhenSelected value
    /// </summary>
    /// <param name="listBoxItem"></param>
    /// <param name="value"></param>
    public static void SetIsBroughtIntoViewWhenSelected(
      ListView listBoxItem, bool value)
    {
      listBoxItem.SetValue(IsBroughtIntoViewWhenSelectedProperty, value);
    }

    /// <summary>
    /// Action to take when item is brought into view
    /// </summary>
    /// <param name="depObj"></param>
    /// <param name="e"></param>
    private static void OnIsBroughtIntoViewWhenSelectedChanged(
      DependencyObject depObj, DependencyPropertyChangedEventArgs e)
    {
      ListView item = depObj as ListView;
      if (item == null)
        return;

      if (e.NewValue is bool == false)
        return;

      if ((bool)e.NewValue)
        item.SelectionChanged += OnListViewItemSelected;
      else
        item.SelectionChanged -= OnListViewItemSelected;
    }

    private static void OnListViewItemSelected(object sender, RoutedEventArgs e)
    {
      // Only react to the Selected event raised by the ListViewItem
      // whose IsSelected property was modified.  Ignore all ancestors 
      // who are merely reporting that a descendant's Selected fired. 
      if (!object.ReferenceEquals(sender, e.OriginalSource))
        return;

      ListView lv = e.OriginalSource as ListView;
      if (lv != null)
      {
        ////lv.SelectedItem = lv.Items.GetItemAt(lv.Items.Count - 1);
        if (lv.SelectedItem != null)
        {
          lv.ScrollIntoView(lv.SelectedItem);
          ListViewItem item = lv.ItemContainerGenerator.ContainerFromItem(lv.SelectedItem) as ListViewItem;

          if (item != null)
            item.Focus();
        }
      }
    }
  }
}

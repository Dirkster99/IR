﻿namespace LabelWithContextMenu.Unit.Distance
{
  using System;
  using LabelWithContextMenu.Unit;
  using LabelWithContextMenu.Unit.Distance.Metric;

  public class DistanceConverter : Converter
  {
    override public double Convert(Itemkey inputUnit, double inputValue, Itemkey outputUnit)
    {
      switch (inputUnit)
	    {
		    case Itemkey.DisMetricKilometer:
          return Kilometer.ToUnit(inputValue, outputUnit);

        case Itemkey.DisMetricMeter:
          return Meter.ToUnit(inputValue, outputUnit);

        case Itemkey.DisMetricCentimeter:
          return DistanceCentimeter.ToUnit(inputValue, outputUnit);

        case Itemkey.DisMetricMillimeter:
          return DistanceMillimeter.ToUnit(inputValue, outputUnit);

        case Itemkey.DisMetricNanometer:
          return NanoMeter.ToUnit(inputValue, outputUnit);

        default:
          throw new NotImplementedException(outputUnit.ToString());
	    }
    }
  }
}

﻿namespace LabelWithContextMenu.Unit.Distance.Metric
{
  using System;

  public sealed class DistanceCentimeter
  {
    private double mValue = 0;

    #region constructor
    public DistanceCentimeter(double value)
    {
      this.mValue = value;
    }

    private DistanceCentimeter()
    {
      
    }
    #endregion constructor

    #region methods
    public static double ToUnit(double inputValue, Itemkey targetUnit)
    {
      DistanceCentimeter d = new DistanceCentimeter(inputValue);

      return d.ToUnit(targetUnit);
    }

    public double ToUnit(Itemkey targetUnit)
    {
      switch (targetUnit)
      {
        case Itemkey.DisMetricKilometer:
          return this.mValue * (1 / 100000.0);
                               
        case Itemkey.DisMetricMeter:
          return this.mValue * (1 / 100.0);

        case Itemkey.DisMetricCentimeter:
          return this.mValue;

        case Itemkey.DisMetricMillimeter:
          return this.mValue * 10.0;

        case Itemkey.DisMetricNanometer:
          return this.mValue * 10000000.0;

        default:
          throw new NotImplementedException(targetUnit.ToString());
      }
    }
    #endregion methods
  }
}

﻿namespace HTMLTitleParser.View
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using Microsoft.Win32;

    /// <summary>
    /// This class customizes the WPF environment to manage
    /// the global command framework for the application.
    /// 
    /// It also contains some static helper methods and variables
    /// to access standard system directories and such...
    /// </summary>
    public class Main
    {
        public const string FileFilterHTML = "htm (*.htm) |*.htm" +
                                            "|All Files (*.*) |*.*";

        #region CommandFramwork
        #region CommandFramework Fields
        private static RoutedUICommand processHTML;
        private static RoutedUICommand cancelProcess;
        private static RoutedUICommand multiProcessHTML;
        private static RoutedUICommand cancelMultiProcess;
        #endregion CommandFramework Fields

        #region Static Constructor
        /// <summary>
        /// Define custom commands and their key gestures
        /// </summary>
        static Main()
        {
            // Use costum text for pre-defined WPF commands
            Main.RenameWPFCommands();

            InputGestureCollection inputs = new InputGestureCollection();      // Initialize the restoreDB command
            ////inputs.Add(new KeyGesture(Key.R, ModifierKeys.Control));
            Main.processHTML = new RoutedUICommand("Process HTML", "ProcessHTML", typeof(Main), inputs);

            inputs = new InputGestureCollection();      // Initialize the restoreDB command
            ////inputs.Add(new KeyGesture(Key.R, ModifierKeys.Control));
            Main.cancelProcess = new RoutedUICommand("Cancel", "Cancel", typeof(Main), inputs);

            inputs = new InputGestureCollection();      // Initialize the restoreDB command
            ////inputs.Add(new KeyGesture(Key.R, ModifierKeys.Control));
            Main.multiProcessHTML = new RoutedUICommand("Process HTML", "MultiProcessHTML", typeof(Main), inputs);

            inputs = new InputGestureCollection();      // Initialize the restoreDB command
            ////inputs.Add(new KeyGesture(Key.R, ModifierKeys.Control));
            Main.cancelMultiProcess = new RoutedUICommand("Cancel", "CancelMultiProcess", typeof(Main), inputs);
        }
        #endregion Static Constructor

        #region CommandFramwork_Properties
        public static RoutedUICommand ProcessHTML
        {
          get { return Main.processHTML; }
        }

        public static RoutedUICommand CancelProcess
        {
          get { return Main.cancelProcess; }
        }

        public static RoutedUICommand MultiProcessHTML
        {
          get { return Main.multiProcessHTML; }
        }

        public static RoutedUICommand CancelMultiProcess
        {
          get { return Main.cancelMultiProcess; }
        }
        #endregion CommandFramwork_Properties
        #endregion CommandFramwork

        #region DirProperties
        internal static string DirMyDocuments
        {
            get
            {
                return Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            }
        }
        #endregion DirProperties

        #region Methods
        /// <summary>
        /// Use costum text for pre-defined WPF commands
        /// </summary>
        public static void RenameWPFCommands()
        {
            ApplicationCommands.Open.Text = "Open HTML File";
        }
        #endregion Methods
    }
}

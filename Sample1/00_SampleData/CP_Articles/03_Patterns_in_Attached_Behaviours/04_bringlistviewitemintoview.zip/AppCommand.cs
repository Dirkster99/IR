﻿namespace BringListViewItemIntoView
{
  using System.Windows.Input;

  class AppCommand
  {
    private static RoutedUICommand processing;

    static AppCommand()
    {
      InputGestureCollection inputs = null;

      // Initialize the exit command
      inputs = new InputGestureCollection();
      AppCommand.processing = new RoutedUICommand("Processing", "Processing", typeof(AppCommand));
    }

    /// <summary>
    /// Static property of the correspondong <seealso cref="System.Windows.Input.RoutedUICommand"/>
    /// </summary>
    public static RoutedUICommand Processing
    {
      get { return AppCommand.processing; }
    }
  }
}

﻿namespace SimpleControls.Hyperlink
{
  using System.Diagnostics;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Input;

  /// <summary>
  /// Interaction logic for WebHyperlink.xaml
  /// </summary>
  public partial class WebHyperlink : UserControl
  {
    #region fields
    public static readonly DependencyProperty NavigateUriProperty =
      DependencyProperty.Register("NavigateUri", typeof(System.Uri), typeof(WebHyperlink));

    public static readonly DependencyProperty TextProperty =
      DependencyProperty.Register("Text", typeof(string), typeof(WebHyperlink));

    private static RoutedCommand mCopyUri;
    private static RoutedCommand mNavigateToUri;
    #endregion fields

    #region constructor
    static WebHyperlink()
    {
      WebHyperlink.mCopyUri = new RoutedCommand("CopyUri", typeof(WebHyperlink));

      CommandManager.RegisterClassCommandBinding(typeof(WebHyperlink), new CommandBinding(mCopyUri, CopyHyperlinkUri));
      CommandManager.RegisterClassInputBinding(typeof(WebHyperlink), new InputBinding(mCopyUri, new KeyGesture(Key.C, ModifierKeys.Control, "Ctrl-C")));

      WebHyperlink.mNavigateToUri = new RoutedCommand("NavigateToUri", typeof(WebHyperlink));
      CommandManager.RegisterClassCommandBinding(typeof(WebHyperlink), new CommandBinding(mNavigateToUri, Hyperlink_CommandNavigateTo));
      ////CommandManager.RegisterClassInputBinding(typeof(WebHyperlink), new InputBinding(mCopyUri, new KeyGesture(Key.C, ModifierKeys.Control, "Ctrl-C")));
    }

    public WebHyperlink()
    {
      this.InitializeComponent();
    }
    #endregion constructor

    #region properties
    public static RoutedCommand CopyUri
    {
      get
      {
        return WebHyperlink.mCopyUri;
      }
    }

    public static RoutedCommand NavigateToUri
    {
      get
      {
        return WebHyperlink.mNavigateToUri;
      }
    }

    /// <summary>
    /// Declare NavigateUri property to allow a user who clicked
    /// on the dispalyed Hyperlink to navigate their with their installed browser...
    /// </summary>
    public System.Uri NavigateUri
    {
      get { return (System.Uri)GetValue(WebHyperlink.NavigateUriProperty); }
      set { SetValue(WebHyperlink.NavigateUriProperty, value); }
    }

    public string Text
    {
      get { return (string)GetValue(WebHyperlink.TextProperty); }
      set { SetValue(WebHyperlink.TextProperty, value); }
    }
    #endregion

    #region Methods
    /// <summary>
    /// Process command when a hyperlink has been clicked.
    /// Start a web browser and let it browse to where this points to...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private static void Hyperlink_CommandNavigateTo(object sender, ExecutedRoutedEventArgs e)
    {
      if (sender == null || e == null) return;

      e.Handled = true;

      WebHyperlink whLink = sender as WebHyperlink;

      if (whLink == null) return;

      Process.Start(new ProcessStartInfo(whLink.NavigateUri.AbsoluteUri));
    }

    /// <summary>
    /// A hyperlink has been clicked. Start a web browser and let it browse to where this points to...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private static void CopyHyperlinkUri(object sender, ExecutedRoutedEventArgs e)
    {
      if (sender == null || e == null) return;

      e.Handled = true;

      WebHyperlink whLink = sender as WebHyperlink;

      if (whLink == null) return;

      System.Windows.Clipboard.SetText(whLink.NavigateUri.AbsoluteUri);
    }

    /// <summary>
    /// A hyperlink has been clicked. Start a web browser and let it browse to where this points to...
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
    {
      Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
    }
    #endregion
  }
}

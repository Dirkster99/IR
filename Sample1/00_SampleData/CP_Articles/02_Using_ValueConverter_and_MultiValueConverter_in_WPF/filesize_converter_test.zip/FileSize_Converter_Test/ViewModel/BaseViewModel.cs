﻿namespace FileSize_Converter_Test.ViewModel
{
  using System;
  using System.ComponentModel;

  /// <summary>
  /// Every ViewModel class is required to implement the INotifyPropertyChanged
  /// interface in order to tell WPF when a property changed (for instance, when
  /// a method or setter is executed).
  /// 
  /// Therefore, the PropertyChanged methode has to be called when data changes,
  /// because the relevant properties may or may not be bound to GUI elements,
  /// which in turn have to refresh their display.
  /// 
  /// The PropertyChanged method is to be called by the members and properties of
  /// the class that derives from this class. Each call contains the name of the
  /// property that has to be refreshed.
  /// </summary>
  public class BaseViewModel : INotifyPropertyChanged
  {
    public event PropertyChangedEventHandler PropertyChanged;

    public void OnPropertyChanged(string propertyName)
    {
      if (this.PropertyChanged != null)
        this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
